# -*- coding: utf-8 -*-
"""视觉专家：把实验照片转成可检索、可展示的可见现象。

只描述照片里能看到的内容，不下化学结论。默认对接 Qwen3-VL 的
OpenAI 兼容接口；测试环境可使用 VISION_BACKEND=mock。
"""

from __future__ import annotations

import json
import os
import re
import time
from typing import Any

import requests


class VisionError(RuntimeError):
    pass


def clip(value: Any, limit: int = 500) -> str:
    return str(value or "").strip()[:limit]


def as_list(value: Any, limit: int = 8) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        parts = [value]
    elif isinstance(value, (list, tuple)):
        parts = value
    else:
        parts = [value]
    result: list[str] = []
    for part in parts:
        text = clip(part, 300)
        if text and text not in result:
            result.append(text)
        if len(result) >= limit:
            break
    return result


class VisionEngine:
    name = "qwen3-vl"

    def __init__(self) -> None:
        self.backend = os.environ.get("VISION_BACKEND", "auto").strip().lower()
        self.provider = os.environ.get("VISION_PROVIDER_NAME", "Qwen3-VL").strip()
        self.api_base = os.environ.get(
            "VISION_API_BASE",
            "https://dashscope.aliyuncs.com/compatible-mode/v1",
        ).rstrip("/")
        self.api_key = os.environ.get("VISION_API_KEY", "").strip()
        self.model = os.environ.get("VISION_MODEL", "qwen3-vl-plus").strip()
        self.trust_env = os.environ.get("VISION_TRUST_ENV", "0").lower() in {
            "1",
            "true",
            "yes",
        }
        self.last_error = ""
        self.last_checked = time.strftime("%Y-%m-%d %H:%M:%S")
        self.refresh()

    def refresh(self) -> None:
        if self.backend == "auto":
            self.backend = "qwen" if self.api_key else "none"
        self.last_checked = time.strftime("%Y-%m-%d %H:%M:%S")

    @property
    def configured(self) -> bool:
        if self.backend == "mock":
            return True
        return self.backend not in {"none", "disabled", "off"} and bool(self.api_key)

    def status(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "backend": self.backend,
            "provider": self.provider,
            "configured": self.configured,
            "model": self.model,
            "last_error": self.last_error,
            "last_checked": self.last_checked,
            "mode": self.provider if self.configured else "未配置",
        }

    def _chat_url(self) -> str:
        if self.api_base.endswith("/chat/completions"):
            return self.api_base
        if self.api_base.endswith("/v1"):
            return f"{self.api_base}/chat/completions"
        return f"{self.api_base}/v1/chat/completions"

    def _session(self) -> requests.Session:
        session = requests.Session()
        session.trust_env = self.trust_env
        return session

    def describe(
        self, image_base64: str, image_mime: str, user_text: str = ""
    ) -> dict[str, Any]:
        if self.backend == "mock":
            return self._mock_result(user_text)
        if not self.configured:
            raise VisionError("图片识别未配置 VISION_API_KEY")

        prompt = f"""这是学生在化学实验现场拍的照片。只描述照片中能直接看到的内容，不判断操作对错，不给诊断结论。

学生补充文字：{user_text or "（没有补充）"}

重点观察：
1. 溶液颜色、浑浊、沉淀、分层、气泡；
2. 滴定终点颜色、指示剂颜色；
3. 仪器读数、刻度、液面位置（能看清才写）；
4. 装置连接、冷凝水、加热状态等明显可见信息；
5. 哪些信息照片看不清，不能据此判断。

输出纯 JSON，不要 Markdown：
{{
  "summary": "一句话描述照片中最关键的现象",
  "visible": ["可见现象，最多 5 条"],
  "readings": ["能看清的读数或标签，没有就空数组"],
  "uncertain": ["照片无法判断的内容，最多 3 条"],
  "quality": "清晰|一般|无法判断",
  "confidence": "高|中|低",
  "search_text": "用于检索知识库的简短现象描述"
}}"""
        data_url = f"data:{image_mime};base64,{image_base64}"
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": "你是化学实验照片的观察员，只报告可见信息，不做诊断。",
                },
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ],
                },
            ],
            "temperature": 0.1,
            "max_tokens": 1800,
            "stream": False,
            "response_format": {"type": "json_object"},
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
        }
        try:
            response = self._session().post(
                self._chat_url(), headers=headers, json=payload, timeout=(8, 75)
            )
            if response.status_code == 400 and "response_format" in response.text:
                payload.pop("response_format", None)
                response = self._session().post(
                    self._chat_url(), headers=headers, json=payload, timeout=(8, 75)
                )
            response.raise_for_status()
            body = response.json()
            content = body["choices"][0]["message"]["content"]
        except (requests.RequestException, KeyError, IndexError, TypeError) as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            raise VisionError(f"视觉模型调用失败：{clip(exc, 300)}") from exc

        if not content:
            raise VisionError("视觉模型返回了空内容")
        parsed = self._parse_json(content)
        result = self._normalize(parsed, content)
        self.last_error = ""
        return result

    @staticmethod
    def _parse_json(raw: str) -> dict[str, Any]:
        text = raw.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)
        start = text.find("{")
        if start < 0:
            return {"summary": text}
        try:
            value, _ = json.JSONDecoder().raw_decode(text[start:])
            return value if isinstance(value, dict) else {"summary": text}
        except json.JSONDecodeError:
            return {"summary": text}

    def _normalize(self, parsed: dict[str, Any], fallback_text: str) -> dict[str, Any]:
        summary = clip(parsed.get("summary"), 500) or clip(fallback_text, 500)
        visible = as_list(parsed.get("visible"), limit=5)
        readings = as_list(parsed.get("readings"), limit=5)
        uncertain = as_list(parsed.get("uncertain"), limit=3)
        search_text = clip(parsed.get("search_text"), 500)
        if not search_text:
            search_text = " ".join([summary, *visible, *readings]).strip()
        quality = parsed.get("quality", "")
        if quality not in {"清晰", "一般", "无法判断"}:
            quality = "一般"
        confidence = parsed.get("confidence", "低")
        if confidence not in {"高", "中", "低"}:
            confidence = "低"
        return {
            "provider": self.provider,
            "model": self.model,
            "summary": summary,
            "visible": visible,
            "readings": readings,
            "uncertain": uncertain,
            "quality": quality,
            "confidence": confidence,
            "search_text": search_text,
        }

    def _mock_result(self, user_text: str) -> dict[str, Any]:
        return {
            "provider": "Mock Vision",
            "model": "mock",
            "summary": "测试模式：已收到实验照片（未进行真实图像识别）",
            "visible": ["测试模式占位：溶液颜色/沉淀等信息由真实视觉模型返回"],
            "readings": [],
            "uncertain": ["测试模式无法判断真实实验现象"],
            "quality": "一般",
            "confidence": "低",
            "search_text": user_text or "实验照片 现象",
        }
