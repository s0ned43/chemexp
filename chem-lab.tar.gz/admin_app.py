# -*- coding: utf-8 -*-
"""独立知识库管理台。

这是与学生端分开的本地管理服务，默认只监听 127.0.0.1:8600。
管理员用与学生端相同的管理员账号登录，上传的文字/PDF 会进入
独立的知识文档表，发布后被学生端检索使用。
"""

from __future__ import annotations

import hmac
import os
import re
import socket
import threading
import time
import webbrowser
from contextlib import asynccontextmanager
from io import BytesIO
from pathlib import Path
from typing import Any
from urllib.parse import quote

import uvicorn
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pypdf import PdfReader

import database as db
from engine import load_kb

BASE = Path(__file__).resolve().parent


def load_env_file(path: Path) -> None:
    if not path.exists():
        return
    try:
        for raw in path.read_text(encoding="utf-8-sig").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[7:].strip()
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key, value = key.strip(), value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                value = value[1:-1]
            if key and key not in os.environ:
                os.environ[key] = value
    except OSError:
        pass


load_env_file(BASE / "server.env")
KB = load_kb()
HOST = os.environ.get("ADMIN_HOST", "127.0.0.1")
PORT = int(os.environ.get("ADMIN_PORT", "8600"))
COOKIE = "lab_admin_session"
SESSION_SECURE = os.environ.get("ADMIN_SESSION_SECURE", "0").lower() in {
    "1",
    "true",
    "yes",
}
MAX_FILE = 5 * 1024 * 1024


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init_db(KB.data)
    print(f"[admin] 独立知识库管理台：http://127.0.0.1:{PORT}")
    yield


app = FastAPI(
    title="实验台 · 知识库管理台",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
    lifespan=lifespan,
)
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE / "templates"))


@app.middleware("http")
async def headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self'; script-src 'self'; "
        "img-src 'self' data:; object-src 'none'; base-uri 'self'; "
        "form-action 'self'; frame-ancestors 'none'"
    )
    response.headers["Cache-Control"] = "no-store"
    return response


def _ctx(request: Request) -> dict[str, Any] | None:
    user = db.resolve_session(request.cookies.get(COOKIE))
    if not user or user.get("role") != "admin" or not user.get("is_active"):
        return None
    user["_raw_token"] = request.cookies.get(COOKIE)
    return user


def _require_ctx(request: Request) -> dict[str, Any]:
    ctx = _ctx(request)
    if not ctx:
        raise HTTPException(status_code=303, headers={"Location": "/login"})
    return ctx


def _check_csrf(ctx: dict[str, Any], token: str) -> None:
    if not token or not hmac.compare_digest(token, ctx.get("csrf_token", "")):
        raise HTTPException(status_code=403, detail="页面已过期，请刷新后重试")


def _chunks(text: str, size: int = 1200) -> list[str]:
    text = re.sub(r"\r\n?", "\n", text).strip()
    if not text:
        return []
    parts = re.split(r"\n{2,}", text)
    result: list[str] = []
    buffer = ""
    for part in parts:
        part = part.strip()
        if not part:
            continue
        while len(part) > size:
            if buffer:
                result.append(buffer)
                buffer = ""
            result.append(part[:size])
            part = part[size:]
        if len(buffer) + len(part) + 2 > size and buffer:
            result.append(buffer)
            buffer = part
        else:
            buffer = f"{buffer}\n\n{part}".strip()
    if buffer:
        result.append(buffer)
    return [item for item in result if item]


def _extract_file(filename: str, data: bytes) -> str:
    lower = filename.lower()
    if lower.endswith(".pdf"):
        try:
            reader = PdfReader(BytesIO(data))
            return "\n\n".join((page.extract_text() or "").strip() for page in reader.pages).strip()
        except Exception as exc:  # noqa: BLE001
            raise ValueError(f"PDF 解析失败：{exc}") from exc
    if lower.endswith((".txt", ".md", ".markdown", ".csv")):
        for encoding in ("utf-8-sig", "utf-8", "gb18030"):
            try:
                return data.decode(encoding)
            except UnicodeDecodeError:
                continue
        raise ValueError("无法识别文件编码，请另存为 UTF-8 后重试")
    raise ValueError("只支持 .txt、.md、.csv、.pdf 文件")


def _exp_options() -> list[dict[str, str]]:
    return [
        {"id": exp["id"], "name": exp["name"], "category": exp.get("category", "")}
        for exp in KB.experiments
    ]


def _render(request: Request, template: str, status_code: int = 200, **context: Any):
    return templates.TemplateResponse(
        request, template, context, status_code=status_code
    )


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if _ctx(request):
        return RedirectResponse("/", status_code=303)
    return _render(request, "admin_login.html", error="")


@app.post("/login")
def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
):
    user = db.authenticate(username, password, "admin")
    if not user:
        return _render(request, "admin_login.html", error="账号、密码或管理员身份不匹配", status_code=401)
    raw, _csrf, _expires = db.create_session(
        user["id"], request.headers.get("user-agent", "")
    )
    response = RedirectResponse("/", status_code=303)
    response.set_cookie(
        COOKIE,
        raw,
        max_age=60 * 60 * 12,
        httponly=True,
        samesite="lax",
        secure=SESSION_SECURE,
        path="/",
    )
    return response


@app.post("/logout")
def logout(request: Request, csrf: str = Form("")):
    ctx = _ctx(request)
    if ctx:
        _check_csrf(ctx, csrf)
        db.delete_session(ctx["_raw_token"])
    response = RedirectResponse("/login", status_code=303)
    response.delete_cookie(COOKIE, path="/")
    return response


@app.get("/", response_class=HTMLResponse)
def console(request: Request, msg: str = ""):
    try:
        ctx = _require_ctx(request)
    except HTTPException:
        return RedirectResponse("/login", status_code=303)
    docs = db.list_knowledge_documents(limit=300)
    stats = db.knowledge_document_stats()
    return _render(
        request,
        "admin_console.html",
        user=ctx,
        csrf=ctx["csrf_token"],
        docs=docs,
        stats=stats,
        experiments=_exp_options(),
        message=msg,
    )


@app.post("/upload")
async def upload(
    request: Request,
    csrf: str = Form(...),
    title: str = Form(""),
    experiment_id: str = Form(""),
    step: str = Form(""),
    source: str = Form(""),
    content: str = Form(""),
    publish: str = Form(""),
    file: UploadFile | None = File(None),
):
    ctx = _ctx(request)
    if not ctx:
        return RedirectResponse("/login", status_code=303)
    _check_csrf(ctx, csrf)
    filename = file.filename if file else ""
    file_text = ""
    if file and filename:
        data = await file.read()
        if len(data) > MAX_FILE:
            return RedirectResponse("/?msg=" + quote("文件不能超过 5 MB"), status_code=303)
        if data:
            try:
                file_text = _extract_file(filename, data)
            except ValueError as exc:
                return RedirectResponse("/?msg=" + quote(str(exc)), status_code=303)
    text = (content or "").strip()
    if file_text:
        text = f"{text}\n\n{file_text}".strip() if text else file_text
    if not text:
        return RedirectResponse("/?msg=" + quote("请粘贴内容或上传文件"), status_code=303)
    if len(text) > 200_000:
        return RedirectResponse("/?msg=" + quote("单条知识内容不能超过 20 万字符"), status_code=303)

    exp = KB.experiment(experiment_id) if experiment_id else None
    if experiment_id and not exp:
        return RedirectResponse("/?msg=" + quote("实验不存在"), status_code=303)
    doc_title = title.strip() or (Path(filename).stem if filename else "未命名资料")
    chunks = _chunks(text)
    if not chunks:
        return RedirectResponse("/?msg=" + quote("内容为空，没有可保存的段落"), status_code=303)
    status = "published" if publish == "on" else "draft"
    doc_id = db.create_knowledge_document(
        title=doc_title,
        experiment_id=exp["id"] if exp else "",
        experiment_name=exp["name"] if exp else "",
        step=step.strip(),
        source=source.strip(),
        content=text,
        chunks=chunks,
        status=status,
        user_id=ctx["id"],
    )
    return RedirectResponse(
        "/?msg=" + quote(f"已保存《{doc_title}》，共 {len(chunks)} 段，编号 {doc_id}"),
        status_code=303,
    )


@app.post("/documents/{doc_id}/status")
def change_status(
    doc_id: int,
    request: Request,
    csrf: str = Form(...),
    status: str = Form(...),
):
    ctx = _ctx(request)
    if not ctx:
        return RedirectResponse("/login", status_code=303)
    _check_csrf(ctx, csrf)
    if status not in {"draft", "published"} or not db.get_knowledge_document(doc_id):
        raise HTTPException(status_code=404, detail="文档不存在")
    db.set_knowledge_document_status(doc_id, status)
    label = "已发布" if status == "published" else "已转为草稿"
    return RedirectResponse("/?msg=" + quote(f"{label}，编号 {doc_id}"), status_code=303)


@app.post("/documents/{doc_id}/delete")
def delete_doc(doc_id: int, request: Request, csrf: str = Form(...)):
    ctx = _ctx(request)
    if not ctx:
        return RedirectResponse("/login", status_code=303)
    _check_csrf(ctx, csrf)
    if not db.get_knowledge_document(doc_id):
        raise HTTPException(status_code=404, detail="文档不存在")
    db.delete_knowledge_document(doc_id)
    return RedirectResponse("/?msg=" + quote(f"已删除文档 {doc_id}"), status_code=303)


def _lan_ip() -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except OSError:
        return "127.0.0.1"


if __name__ == "__main__":
    print("=" * 54)
    print("  实验台 · 独立知识库管理台")
    print(f"  本机访问：http://127.0.0.1:{PORT}")
    print(f"  停止服务：按 Ctrl + C")
    print("=" * 54)
    if os.environ.get("ADMIN_OPEN_BROWSER", "1").lower() not in {"0", "false", "no"}:
        threading.Timer(1.0, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}/login")).start()
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")
