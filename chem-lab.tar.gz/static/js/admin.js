(() => {
  document.querySelectorAll("form[data-confirm]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!window.confirm(form.dataset.confirm || "确定执行这个操作？")) {
        event.preventDefault();
      }
    });
  });
})();
