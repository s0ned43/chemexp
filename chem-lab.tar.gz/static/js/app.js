(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const state = {
    boot: null,
    user: null,
    csrf: "",
    kb: null,
    engine: null,
    experiments: [],
    experimentsById: new Map(),
    searchIndex: new Map(),
    sourceMap: new Map(),
    quickPrompts: [],
    libraryCategory: "全部",
    libraryQuery: "",
    records: [],
    recordStats: null,
    recordsLoaded: false,
    recordsLoading: false,
    adminLoaded: false,
    adminLoading: false,
    adminTab: "ops",
    adminOverview: null,
    adminUsers: [],
    adminOps: [],
    opEditingId: null,
    opKind: "standard",
    currentDiagnosisId: null,
    currentFeedback: null,
    searchTimer: null,
    toastTimer: null,
    photo: null,
    visionInfo: null,
  };

  class ApiError extends Error {
    constructor(message, status) {
      super(message);
      this.name = "ApiError";
      this.status = status;
    }
  }

  // -----------------------------------------------------------------------
  // 基础工具
  // -----------------------------------------------------------------------

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function clear(node) {
    node.replaceChildren();
  }

  function append(parent, ...children) {
    children.filter(Boolean).forEach((child) => parent.appendChild(child));
    return parent;
  }

  function firstChar(value) {
    const chars = Array.from(String(value || "").trim());
    return chars.length ? chars[0].toUpperCase() : "同";
  }

  function roleLabel(role) {
    return role === "admin" ? "开发者" : "学生";
  }

  function avatarText(displayName, role) {
    if (role === "admin") return "管";
    return firstChar(displayName);
  }

  function friendlyModel(model) {
    if (!model) return "—";
    const parts = String(model).split(":");
    return parts.length > 1 ? parts[parts.length - 1] : String(model);
  }

  function parseDate(value) {
    if (!value) return null;
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function pad(number) {
    return String(number).padStart(2, "0");
  }

  function formatDateTime(value) {
    const date = parseDate(value);
    if (!date) return "尚未登录";
    return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }

  function formatRecordDate(value) {
    const date = parseDate(value);
    if (!date) return { top: "—", bottom: "—" };
    return {
      top: `${date.getMonth() + 1}.${date.getDate()}`,
      bottom: `${pad(date.getHours())}:${pad(date.getMinutes())}`,
    };
  }

  function formatShort(value) {
    const date = parseDate(value);
    if (!date) return "—";
    return `${date.getMonth() + 1}/${date.getDate()} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }

  function countSymptoms(exp) {
    return (exp.steps || []).reduce((sum, step) => sum + (step.symptoms || []).length, 0);
  }

  function safetyClass(level) {
    if (level === "高") return "safety-level is-high";
    if (level === "中") return "safety-level is-mid";
    return "safety-level";
  }

  function humanSource(source) {
    if (!source) return "";
    return state.sourceMap.get(source) || String(source).replace(/\s*\/\s*/g, " · ");
  }

  function setFormError(node, message) {
    if (!node) return;
    if (!message) {
      node.hidden = true;
      node.textContent = "";
      return;
    }
    node.textContent = message;
    node.hidden = false;
  }

  function showToast(message, isError = false) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.toggle("is-error", Boolean(isError));
    toast.hidden = false;
    window.clearTimeout(state.toastTimer);
    state.toastTimer = window.setTimeout(() => {
      toast.hidden = true;
    }, 3200);
  }

  function setButtonBusy(button, busy, busyText) {
    if (!button) return;
    if (busy) {
      if (!button.dataset.originalText) button.dataset.originalText = button.textContent;
      button.disabled = true;
      if (busyText) button.textContent = busyText;
    } else {
      button.disabled = false;
      if (button.dataset.originalText) button.textContent = button.dataset.originalText;
      delete button.dataset.originalText;
    }
  }

  function showInlineLoading(container, label = "正在读取…") {
    clear(container);
    const wrap = el("div", "result-loading");
    const title = el("div", "loading-line is-title");
    const line = el("div", "loading-line");
    const short = el("div", "loading-line is-short");
    const note = el("p", "loading-note", label);
    append(wrap, title, line, short, note);
    append(container, wrap);
  }

  async function api(path, options = {}) {
    const method = options.method || "GET";
    const headers = { Accept: "application/json", ...(options.headers || {}) };
    const init = {
      method,
      headers,
      credentials: "same-origin",
      cache: "no-store",
    };
    if (method !== "GET" && method !== "HEAD") {
      headers["X-CSRF-Token"] = state.csrf;
    }
    if (options.body !== undefined) {
      headers["Content-Type"] = "application/json";
      init.body = JSON.stringify(options.body);
    }
    let response;
    try {
      response = await fetch(path, init);
    } catch {
      throw new ApiError("无法连接本地服务，请确认启动窗口仍然开着。", 0);
    }
    let data = null;
    const raw = await response.text();
    if (raw) {
      try {
        data = JSON.parse(raw);
      } catch {
        data = null;
      }
    }
    if (response.status === 401) {
      window.location.replace("/login");
      throw new ApiError("登录已过期，请重新登录。", 401);
    }
    if (!response.ok) {
      throw new ApiError(data?.error || data?.detail || `请求失败（${response.status}）`, response.status);
    }
    return data;
  }

  // -----------------------------------------------------------------------
  // 启动与用户
  // -----------------------------------------------------------------------

  async function init() {
    bindEvents();
    try {
      const boot = await api("/api/bootstrap");
      state.boot = boot;
      state.user = boot.user;
      state.csrf = boot.csrf;
      state.kb = boot.kb;
      state.engine = boot.engine;
      state.visionInfo = boot.vision || null;
      state.quickPrompts = boot.quick_prompts || [];
      updateUserChrome();
      renderQuickPrompts();
      await loadExperiments();
      initRoute();
    } catch (error) {
      showFatal(error.message || "页面加载失败");
    }
  }

  function updateUserChrome() {
    const user = state.user;
    if (!user) return;
    const display = user.display_name || user.username || "同学";
    const initial = avatarText(display, user.role);
    $("#avatar-initial").textContent = initial;
    $("#profile-initial").textContent = initial;
    $("#topbar-role").textContent = roleLabel(user.role);
    $("#topbar-role").classList.toggle("is-admin", user.role === "admin");
    $("#nav-me").hidden = user.role === "admin";
    $("#nav-admin").hidden = user.role !== "admin";
    renderProfilePage();
  }

  function renderProfilePage() {
    const user = state.user;
    if (!user) return;
    const display = user.display_name || user.username;
    $("#profile-name").textContent = display;
    const metaParts = [user.student_no, user.class_name].filter(Boolean);
    $("#profile-meta").textContent = metaParts.length ? metaParts.join(" · ") : roleLabel(user.role) + "账号";
    const role = $("#profile-role");
    role.textContent = roleLabel(user.role);
    role.classList.toggle("is-admin", user.role === "admin");
    $("#must-change-banner").hidden = !user.must_change_password;

    const card = $("#profile-card");
    clear(card);
    const heading = el("div", "panel-heading");
    const headingText = el("div");
    append(headingText, el("p", "eyebrow", "ACCOUNT"), el("h3", "", "账号信息"));
    const edit = el("button", "text-button", "编辑资料");
    edit.type = "button";
    edit.addEventListener("click", openEditProfileSheet);
    append(heading, headingText, edit);

    const rows = el("div", "account-rows");
    const rowData = [
      ["登录账号", user.username],
      ["身份", roleLabel(user.role)],
      ["学号 / 工号", user.student_no || "未填写"],
      ["班级", user.class_name || "未填写"],
      ["上次登录", user.last_login_at ? formatDateTime(user.last_login_at) : "首次登录"],
    ];
    rowData.forEach(([label, value]) => {
      const row = el("div", "account-row");
      append(row, el("span", "", label), el("strong", "", value || "—"));
      rows.appendChild(row);
    });
    append(card, heading, rows);

    const about = $("#about-card");
    clear(about);
    const aboutHeading = el("div", "panel-heading");
    const aboutText = el("div");
    append(aboutText, el("p", "eyebrow", "ABOUT"), el("h3", "", "关于实验台"));
    aboutHeading.appendChild(aboutText);
    const kb = state.kb || {};
    append(
      about,
      aboutHeading,
      el(
        "p",
        "",
        "实验台把标准操作、常见误差和实验现象整理成可检索的条目。回答优先参考本地知识库，chem 引擎负责把命中的资料组织成可执行的排查步骤。"
      ),
      el(
        "p",
        "",
        "当前知识库内容为通用实验规范整理，仍需任课教师审核。遇到危险情况，以实验中心安全规定和现场老师判断为准。"
      )
    );
    const tags = el("div", "about-tags");
    [
      `知识库 v${kb.version || "1.0"}`,
      `${kb.experiments || 0} 个实验`,
      `${kb.causes || 0} 条原因`,
      `${state.engine?.name || "chem"} · ${friendlyModel(state.engine?.model)}`,
      kb.review_status || "待审核",
    ].forEach((text) => tags.appendChild(el("span", "about-tag", text)));
    about.appendChild(tags);
  }

  function renderQuickPrompts() {
    const row = $("#quick-prompts");
    clear(row);
    state.quickPrompts.forEach((item) => {
      const button = el("button", "quick-chip", item.label);
      button.type = "button";
      button.dataset.prompt = item.label;
      button.dataset.experimentId = item.experiment_id || "";
      row.appendChild(button);
    });
  }

  function showFatal(message) {
    const form = $("#diagnose-form");
    if (form) form.hidden = true;
    const result = $("#diagnosis-result");
    result.hidden = false;
    clear(result);
    const box = el("div", "empty-state");
    append(
      box,
      el("h4", "", "页面没有加载成功"),
      el("p", "", message || "请刷新页面重试。"),
    );
    const retry = el("button", "secondary-button", "刷新页面");
    retry.type = "button";
    retry.addEventListener("click", () => window.location.reload());
    box.appendChild(retry);
    result.appendChild(box);
  }

  // -----------------------------------------------------------------------
  // 实验数据
  // -----------------------------------------------------------------------

  async function loadExperiments(force = false) {
    if (!force && state.experiments.length) return;
    const data = await api("/api/experiments");
    state.experiments = data.experiments || [];
    state.kb = data.summary || state.kb;
    rebuildExperimentIndexes();
    populateExperimentSelects();
    renderHomeExperiments();
    renderCategoryFilters();
    renderLibrary();
    if (state.user) renderProfilePage();
  }

  function rebuildExperimentIndexes() {
    state.experimentsById = new Map(state.experiments.map((exp) => [exp.id, exp]));
    state.sourceMap = new Map();
    state.searchIndex = new Map();
    state.experiments.forEach((exp) => {
      const textParts = [
        exp.name,
        exp.category,
        exp.intro,
        exp.principle,
        ...(exp.aliases || []),
      ];
      (exp.steps || []).forEach((step) => {
        textParts.push(step.name, step.expected, ...(step.points || []));
        (step.symptoms || []).forEach((symptom) => {
          textParts.push(symptom.name, ...(symptom.aliases || []));
          state.sourceMap.set(
            `${exp.id}/${step.id}/${symptom.id}`,
            `${exp.name} · ${step.name} · ${symptom.name}`
          );
        });
      });
      state.searchIndex.set(exp.id, textParts.filter(Boolean).join(" ").toLowerCase());
    });
  }

  function populateExperimentSelects() {
    const diagnosis = $("#experiment-select");
    if (diagnosis) {
      const current = diagnosis.value;
      clear(diagnosis);
      const placeholder = new Option("不指定，自动匹配", "");
      diagnosis.add(placeholder);
      addGroupedOptions(diagnosis);
      if (Array.from(diagnosis.options).some((option) => option.value === current)) {
        diagnosis.value = current;
      }
    }

    const opSelect = $("#op-experiment");
    if (opSelect) {
      const current = opSelect.value;
      clear(opSelect);
      opSelect.add(new Option("选择实验", ""));
      state.experiments.forEach((exp) => opSelect.add(new Option(exp.name, exp.id)));
      if (Array.from(opSelect.options).some((option) => option.value === current)) {
        opSelect.value = current;
      }
    }

    ["#ops-filter-experiment"].forEach((selector) => {
      const select = $(selector);
      if (!select) return;
      const current = select.value;
      clear(select);
      select.add(new Option("全部实验", ""));
      state.experiments.forEach((exp) => select.add(new Option(exp.name, exp.id)));
      if (Array.from(select.options).some((option) => option.value === current)) {
        select.value = current;
      }
    });
  }

  function addGroupedOptions(select) {
    const groups = new Map();
    state.experiments.forEach((exp) => {
      const category = exp.category || "其他";
      if (!groups.has(category)) groups.set(category, []);
      groups.get(category).push(exp);
    });
    groups.forEach((items, category) => {
      const group = document.createElement("optgroup");
      group.label = category;
      items.forEach((exp) => group.appendChild(new Option(exp.name, exp.id)));
      select.appendChild(group);
    });
  }

  function renderHomeExperiments() {
    const container = $("#home-experiments");
    clear(container);
    const items = state.experiments.slice(0, 7);
    if (!items.length) {
      const empty = el("div", "empty-state");
      append(empty, el("h4", "", "实验库为空"), el("p", "", "知识库文件可能没有成功读取。"));
      container.appendChild(empty);
      return;
    }
    items.forEach((exp) => {
      const button = el("button", "mini-experiment");
      button.type = "button";
      button.dataset.expId = exp.id;
      append(
        button,
        el("span", "cat", exp.category || "基础实验"),
        el("h4", "", exp.name),
        el("p", "", exp.intro || ""),
        el(
          "span",
          "mini-foot",
          `${(exp.steps || []).length} 个步骤 · ${countSymptoms(exp)} 个现象`
        )
      );
      container.appendChild(button);
    });
  }

  function renderCategoryFilters() {
    const container = $("#category-filters");
    if (!container) return;
    const categories = ["全部", ...new Set(state.experiments.map((exp) => exp.category).filter(Boolean))];
    if (!categories.includes(state.libraryCategory)) state.libraryCategory = "全部";
    clear(container);
    categories.forEach((category) => {
      const button = el("button", "filter-chip", category);
      button.type = "button";
      button.dataset.category = category;
      button.classList.toggle("is-active", category === state.libraryCategory);
      container.appendChild(button);
    });
  }

  function filteredExperiments() {
    const tokens = state.libraryQuery
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean);
    return state.experiments.filter((exp) => {
      if (state.libraryCategory !== "全部" && exp.category !== state.libraryCategory) return false;
      if (!tokens.length) return true;
      const haystack = state.searchIndex.get(exp.id) || "";
      return tokens.every((token) => haystack.includes(token));
    });
  }

  function renderLibrary() {
    const list = $("#library-list");
    if (!list) return;
    const items = filteredExperiments();
    const count = $("#library-count");
    if (count) {
      count.textContent = state.libraryQuery
        ? `找到 ${items.length} 个实验`
        : `共 ${state.experiments.length} 个实验 · ${items.length} 个当前显示`;
    }
    clear(list);
    if (!items.length) {
      const empty = el("div", "empty-state");
      append(empty, el("h4", "", "没有匹配的实验"), el("p", "", "换一个关键词，或清除类别筛选再试。"));
      const clearButton = el("button", "secondary-button", "清除筛选");
      clearButton.type = "button";
      clearButton.dataset.clearLibrary = "1";
      empty.appendChild(clearButton);
      list.appendChild(empty);
      return;
    }
    items.forEach((exp) => {
      const button = el("button", "experiment-card");
      button.type = "button";
      button.dataset.expId = exp.id;

      const top = el("div", "exp-card-top");
      append(top, el("span", "exp-category", exp.category || "基础实验"), el("span", safetyClass(exp.safety_level), `安全 ${exp.safety_level || "未标注"}`));

      const meta = el("div", "exp-meta");
      const standardCount = exp.operations?.standard?.length || 0;
      const errorCount = exp.operations?.error?.length || 0;
      [
        `${(exp.steps || []).length} 个步骤`,
        `${countSymptoms(exp)} 个现象`,
        `${standardCount} 条标准`,
        `${errorCount} 条误差`,
      ].forEach((text) => meta.appendChild(el("span", "", text)));

      append(button, top, el("h3", "", exp.name), el("p", "", exp.intro || ""), meta);
      list.appendChild(button);
    });
  }

  function renderExperimentDetail(expId) {
    const exp = state.experimentsById.get(expId);
    if (!exp) {
      showToast("这个实验不在当前知识库中。", true);
      window.location.hash = "library";
      return;
    }

    $("#library-overview").hidden = true;
    const detail = $("#experiment-detail");
    detail.hidden = false;
    const content = $("#experiment-detail-content");
    clear(content);

    const hero = el("header", "detail-hero");
    const tags = el("div", "detail-tags");
    [
      exp.category || "基础实验",
      `${(exp.steps || []).length} 个步骤`,
      `安全等级 ${exp.safety_level || "未标注"}`,
    ].forEach((text) => tags.appendChild(el("span", "detail-tag", text)));
    append(
      hero,
      el("p", "eyebrow", "EXPERIMENT"),
      el("h2", "", exp.name),
      el("p", "detail-intro", exp.intro || ""),
      exp.principle ? el("p", "principle", exp.principle) : null,
      tags
    );
    content.appendChild(hero);

    if ((exp.safety || []).length) {
      const safety = el("div", "safety-callout");
      const symbol = el("div", "callout-symbol", "!");
      const copy = el("div");
      const listItems = el("ul");
      exp.safety.forEach((line) => listItems.appendChild(el("li", "", line)));
      append(copy, el("h4", "", "安全提示"), listItems);
      append(safety, symbol, copy);
      content.appendChild(safety);
    }

    const stepsSection = el("section", "detail-section");
    const stepsHead = el("div", "detail-section-head");
    append(stepsHead, el("h3", "", "操作步骤"), el("p", "", `${(exp.steps || []).length} 步`));
    const stepList = el("div", "step-list");
    (exp.steps || []).forEach((step, index) => {
      const card = el("div", "step-card");
      const top = el("div", "step-top");
      append(top, el("span", "step-number", String(index + 1).padStart(2, "0")), el("h4", "", step.name));
      card.appendChild(top);
      if ((step.points || []).length) {
        const points = el("ul", "step-points");
        step.points.forEach((point) => points.appendChild(el("li", "", point)));
        card.appendChild(points);
      }
      if (step.expected) {
        const expected = el("p", "expected-line");
        expected.appendChild(el("strong", "", "预期："));
        expected.appendChild(document.createTextNode(step.expected));
        card.appendChild(expected);
      }
      const symptomButtons = el("div", "symptom-buttons");
      (step.symptoms || []).forEach((symptom) => {
        const button = el("button", "symptom-button", symptom.name);
        button.type = "button";
        button.dataset.symptom = symptom.name;
        button.dataset.expId = exp.id;
        symptomButtons.appendChild(button);
      });
      if (symptomButtons.childElementCount) card.appendChild(symptomButtons);
      stepList.appendChild(card);
    });
    append(stepsSection, stepsHead, stepList);
    content.appendChild(stepsSection);

    const operations = exp.operations || { standard: [], error: [] };
    const opsSection = el("section", "detail-section");
    const opsHead = el("div", "detail-section-head");
    append(
      opsHead,
      el("h3", "", "标准操作与误差数据"),
      el("p", "", `${(operations.standard || []).length + (operations.error || []).length} 条`)
    );
    opsSection.appendChild(opsHead);

    if (!(operations.standard || []).length && !(operations.error || []).length) {
      const empty = el("div", "empty-state");
      append(empty, el("h4", "", "还没有操作数据"), el("p", "", "开发者可以在「管理 → 操作数据」中补充。"));
      opsSection.appendChild(empty);
    } else {
      if ((operations.standard || []).length) {
        const group = el("div", "operation-group");
        const head = el("div", "operation-group-head");
        append(head, el("span", "op-kind-tag", "标准操作"), el("h4", "", `${operations.standard.length} 条`));
        group.appendChild(head);
        operations.standard.forEach((op) => group.appendChild(buildLibraryOpCard(op, "standard")));
        opsSection.appendChild(group);
      }
      if ((operations.error || []).length) {
        const group = el("div", "operation-group");
        const head = el("div", "operation-group-head");
        append(head, el("span", "op-kind-tag is-error", "误差操作"), el("h4", "", `${operations.error.length} 条`));
        group.appendChild(head);
        operations.error.forEach((op) => group.appendChild(buildLibraryOpCard(op, "error")));
        opsSection.appendChild(group);
      }
    }
    content.appendChild(opsSection);

    if (state.user?.role === "admin") {
      const hint = el("div", "admin-data-hint");
      hint.appendChild(el("strong", "", "开发者入口："));
      hint.appendChild(
        document.createTextNode("在底部「管理」→「操作数据」中维护本实验的标准操作和误差操作，保存后立即用于排障。")
      );
      content.appendChild(hint);
    }

    const source = el("div", "detail-source");
    source.textContent = `来源：${exp.source || "未标注"} · ${state.kb?.review_status || "待审核"}`;
    content.appendChild(source);
    $("#page-scroll").scrollTo({ top: 0, behavior: "auto" });
  }

  function buildLibraryOpCard(op, kind) {
    const card = el("div", "library-op-card");
    const head = el("div", "library-op-head");
    const titleBox = el("div");
    append(titleBox, el("h5", "", op.title || "未命名记录"));
    append(titleBox, el("span", "library-op-step", [op.experiment_name, op.step].filter(Boolean).join(" · ")));
    head.appendChild(titleBox);
    if (kind === "error" && op.severity) {
      head.appendChild(
        el("span", op.severity === "高" ? "severity-tag is-high" : "severity-tag", `严重 ${op.severity}`)
      );
    }
    card.appendChild(head);

    const facts = el("div", "op-facts");
    const pairs =
      kind === "standard"
        ? [
            ["条件", op.conditions],
            ["预期", op.expected],
          ]
        : [
            ["实际", op.observed],
            ["偏差", op.deviation],
            ["原因", op.cause],
          ];
    pairs.forEach(([label, value]) => {
      if (!value) return;
      const row = el("div", "op-fact");
      append(row, el("span", "", label), el("p", "", value));
      facts.appendChild(row);
    });
    card.appendChild(facts);
    if (op.source) card.appendChild(el("span", "library-op-step", `依据：${op.source}`));
    return card;
  }

  // -----------------------------------------------------------------------
  // 路由
  // -----------------------------------------------------------------------

  function initRoute() {
    if (!location.hash) {
      history.replaceState(null, "", "#diagnose");
    }
    applyRoute(parseHash(), true);
  }

  function parseHash() {
    const raw = decodeURIComponent(location.hash.replace(/^#/, ""));
    if (raw.startsWith("exp/")) {
      return { view: "library", detailId: raw.slice(4) };
    }
    if (["diagnose", "library", "records", "me", "admin"].includes(raw)) {
      return { view: raw };
    }
    return { view: "diagnose" };
  }

  function applyRoute(route, initial = false) {
    if (!state.user) return;
    if (route.view === "admin" && state.user.role !== "admin") {
      showToast("当前账号没有开发者权限。", true);
      history.replaceState(null, "", "#diagnose");
      route = { view: "diagnose" };
    }
    if (route.view === "me" && state.user.role === "admin") {
      history.replaceState(null, "", "#admin");
      route = { view: "admin" };
    }

    const view = route.view;
    $$(".page").forEach((page) => {
      page.hidden = page.dataset.page !== view;
    });
    $$(".tab-button").forEach((button) => {
      const active = button.dataset.nav === view;
      button.classList.toggle("is-active", active);
      if (active) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });

    if (view === "library") {
      if (route.detailId) {
        renderExperimentDetail(route.detailId);
      } else {
        $("#library-overview").hidden = false;
        $("#experiment-detail").hidden = true;
      }
    }
    if (view === "records") {
      loadRecords();
    }
    if (view === "admin") {
      loadAdmin();
    }
    if (!initial) {
      $("#page-scroll").scrollTo({ top: 0, behavior: "auto" });
    }
  }

  function navigate(view) {
    if (view === "me" && state.user?.role === "admin") {
      openAccountSheet();
      return;
    }
    const target = `#${view}`;
    if (location.hash === target) {
      applyRoute({ view });
    } else {
      location.hash = target;
    }
  }

  function openExperiment(expId) {
    const target = `#exp/${encodeURIComponent(expId)}`;
    if (location.hash === target) {
      applyRoute(parseHash());
    } else {
      location.hash = target;
    }
  }

  // -----------------------------------------------------------------------
  // 问诊照片
  // -----------------------------------------------------------------------

  function clearPhoto() {
    state.photo = null;
    const input = $("#photo-input");
    if (input) input.value = "";
    const add = $("#photo-add");
    if (add) add.hidden = false;
    $("#photo-preview").hidden = true;
    $("#photo-image").removeAttribute("src");
    $("#photo-name").textContent = "";
  }

  function handlePhotoFile(file) {
    const errorBox = $("#diagnose-error");
    setFormError(errorBox, "");
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      setFormError(errorBox, "照片只支持 JPG、PNG 或 WebP。");
      clearPhoto();
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setFormError(errorBox, "照片不能超过 8 MB。");
      clearPhoto();
      return;
    }
    const add = $("#photo-add");
    add.disabled = true;
    add.textContent = "正在压缩照片…";
    compressPhoto(file)
      .then((photo) => {
        state.photo = photo;
        $("#photo-image").src = photo.preview;
        $("#photo-name").textContent = file.name || "已选择照片";
        $("#photo-preview").hidden = false;
        add.hidden = true;
        if (state.visionInfo && !state.visionInfo.configured) {
          showToast("后台未配置图片识别；提交时请同时写文字描述。", true);
        }
      })
      .catch((error) => {
        clearPhoto();
        setFormError(errorBox, error.message || "照片处理失败，请换一张图片。");
      })
      .finally(() => {
        add.disabled = false;
        add.replaceChildren();
        const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        icon.setAttribute("viewBox", "0 0 20 20");
        icon.setAttribute("fill", "none");
        icon.setAttribute("aria-hidden", "true");
        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
        path.setAttribute("d", "M4 6.5h2l1.2-1.7h5.6L14 6.5h2A1.5 1.5 0 0 1 17.5 8v6A1.5 1.5 0 0 1 16 15.5H4A1.5 1.5 0 0 1 2.5 14V8A1.5 1.5 0 0 1 4 6.5Z");
        path.setAttribute("stroke", "currentColor");
        path.setAttribute("stroke-width", "1.4");
        path.setAttribute("stroke-linejoin", "round");
        const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        circle.setAttribute("cx", "10");
        circle.setAttribute("cy", "11");
        circle.setAttribute("r", "2.6");
        circle.setAttribute("stroke", "currentColor");
        circle.setAttribute("stroke-width", "1.4");
        append(icon, path, circle);
        add.appendChild(icon);
        add.appendChild(document.createTextNode(" 添加一张实验照片"));
      });
  }

  function compressPhoto(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error("读取照片失败"));
      reader.onload = () => {
        const image = new Image();
        image.onerror = () => reject(new Error("无法解析这张图片"));
        image.onload = () => {
          const maxSide = 1280;
          const scale = Math.min(1, maxSide / Math.max(image.width, image.height));
          const width = Math.max(1, Math.round(image.width * scale));
          const height = Math.max(1, Math.round(image.height * scale));
          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;
          const context = canvas.getContext("2d");
          context.fillStyle = "#fff";
          context.fillRect(0, 0, width, height);
          context.drawImage(image, 0, 0, width, height);
          const preview = canvas.toDataURL("image/jpeg", 0.82);
          const data = preview.split(",")[1] || "";
          if (!data) {
            reject(new Error("照片压缩失败"));
            return;
          }
          resolve({ data, mime: "image/jpeg", preview, name: file.name });
        };
        image.src = String(reader.result || "");
      };
      reader.readAsDataURL(file);
    });
  }

  // -----------------------------------------------------------------------
  // 问诊
  // -----------------------------------------------------------------------

  async function handleDiagnose(event) {
    event.preventDefault();
    const input = $("#query");
    const errorBox = $("#diagnose-error");
    const query = input.value.trim();
    const experimentId = $("#experiment-select").value;
    setFormError(errorBox, "");
    if (query.length < 2 && !state.photo) {
      setFormError(errorBox, "至少写两个字，或上传一张实验照片。");
      input.focus();
      return;
    }

    const submit = $("#diagnose-submit");
    const label = submit.querySelector("span");
    submit.disabled = true;
    label.textContent = state.photo ? "正在看照片并排查…" : "正在排查…";
    const result = $("#diagnosis-result");
    result.hidden = false;
    showInlineLoading(
      result,
      state.photo ? "正在识别照片并对照标准操作…" : "正在对照标准操作和常见误差…"
    );
    result.scrollIntoView({ behavior: "smooth", block: "start" });

    try {
      const payload = { query, experiment_id: experimentId };
      if (state.photo) {
        payload.image_data = state.photo.data;
        payload.image_mime = state.photo.mime;
      }
      const data = await api("/api/diagnose", {
        method: "POST",
        body: payload,
      });
      state.currentDiagnosisId = data.id;
      state.currentFeedback = null;
      state.recordsLoaded = false;
      state.adminLoaded = false;
      renderAnswer(result, data.answer, { diagId: data.id, feedback: null });
      window.setTimeout(() => result.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
    } catch (error) {
      result.hidden = true;
      clear(result);
      setFormError(errorBox, error.message || "排查失败，请稍后再试。");
      if (error.status === 429) {
        showToast(error.message, true);
      }
    } finally {
      submit.disabled = false;
      label.textContent = "开始排查";
    }
  }

  function renderAnswer(container, answer, options = {}) {
    clear(container);
    const card = el("div", "result-card");
    const mode = answer?.engine_mode || options.mode || "local";
    const covered = answer?.covered !== false;
    const docMatches = Array.isArray(answer?.document_matches) ? answer.document_matches : [];
    const top = el("div", "result-topline");
    const online = mode === "cherry" || mode === "direct";
    const badge = el("span", online ? "engine-badge" : "engine-badge is-local", online ? "chem" : "本地知识库");
    badge.title = answer?.model || "";
    append(
      top,
      badge,
      el("span", "confidence-tag", `把握 · ${answer?.confidence || "低"}`)
    );
    const heading = covered ? "现场判断" : docMatches.length ? "找到相关资料" : "资料未覆盖";
    append(card, top, el("h3", "", heading));
    append(card, el("p", "result-summary", answer?.summary || "暂时没有可用的判断。"));

    if (answer?.warning) {
      card.appendChild(el("p", "result-warning", answer.warning));
    }
    if (answer?.vision_warning) {
      card.appendChild(el("p", "vision-warning", answer.vision_warning));
    }
    if (answer?.vision) {
      card.appendChild(buildVisionBlock(answer.vision));
    }

    const matches = Array.isArray(answer?.matched) ? answer.matched : [];
    if (matches.length) {
      const first = matches[0];
      const text =
        matches.length > 1
          ? `命中：${first.experiment} · ${first.step} · ${first.symptom} 等 ${matches.length} 条`
          : `命中：${first.experiment} · ${first.step} · ${first.symptom}`;
      card.appendChild(el("p", "result-match", text));
    } else if (docMatches.length) {
      card.appendChild(
        el(
          "p",
          "result-match",
          `参考资料：${docMatches.map((doc) => doc.title).filter(Boolean).slice(0, 3).join(" / ")}`
        )
      );
    }

    if ((answer?.safety || []).length) {
      const safety = el("div", "safety-block");
      safety.appendChild(el("p", "safety-label", "先看安全"));
      const list = el("ul");
      answer.safety.forEach((line) => list.appendChild(el("li", "", line)));
      safety.appendChild(list);
      card.appendChild(safety);
    }

    if (covered && (answer?.causes || []).length) {
      const causes = el("div", "cause-list");
      answer.causes.forEach((cause, index) => {
        const causeCard = el("article", "cause-card");
        const head = el("div", "cause-head");
        const likelihood = cause.likelihood || "中";
        const likelihoodClass =
          likelihood === "高" ? "likelihood high" : likelihood === "中" ? "likelihood medium" : "likelihood";
        append(
          head,
          el("span", "cause-index", String(index + 1).padStart(2, "0")),
          el("h4", "", cause.text || "未命名原因"),
          el("span", likelihoodClass, likelihood)
        );
        causeCard.appendChild(head);
        if (cause.why) causeCard.appendChild(el("p", "cause-why", cause.why));
        if (cause.verify) {
          const row = el("div", "cause-action");
          append(row, el("span", "", "怎么验证"), el("p", "", cause.verify));
          causeCard.appendChild(row);
        }
        if (cause.action) {
          const row = el("div", "cause-action");
          append(row, el("span", "", "怎么处理"), el("p", "", cause.action));
          causeCard.appendChild(row);
        }
        causes.appendChild(causeCard);
      });
      card.appendChild(causes);
    }

    if ((answer?.next_info || []).length) {
      const next = el("div", "next-info");
      next.appendChild(el("p", "", covered ? "还需要补充" : "先补充这些信息"));
      const list = el("ul");
      answer.next_info.forEach((line) => list.appendChild(el("li", "", line)));
      next.appendChild(list);
      card.appendChild(next);
    }

    const sources = Array.isArray(answer?.sources) ? Array.from(new Set(answer.sources.map(humanSource).filter(Boolean))) : [];
    if (sources.length) {
      const details = document.createElement("details");
      details.className = "sources";
      const summary = document.createElement("summary");
      summary.textContent = "参考依据";
      const list = el("ul");
      sources.forEach((source) => list.appendChild(el("li", "", source)));
      append(details, summary, list);
      card.appendChild(details);
    }

    if (options.diagId !== undefined && options.diagId !== null) {
      const feedback = options.feedback === 1 ? 1 : options.feedback === -1 ? -1 : null;
      appendFeedback(card, options.diagId, feedback);
    }
    container.appendChild(card);
  }

  function buildVisionBlock(vision) {
    const block = el("div", "vision-block");
    const top = el("div", "vision-top");
    append(
      top,
      el("span", "vision-label", `照片里看到 · ${vision.provider || "Qwen3-VL"}`),
      el("span", "vision-quality", `图像质量 ${vision.quality || "一般"} · 把握 ${vision.confidence || "低"}`)
    );
    block.appendChild(top);
    if (vision.summary) block.appendChild(el("p", "vision-summary", vision.summary));
    const sections = [
      ["可见现象", vision.visible],
      ["能看清的读数 / 标签", vision.readings],
      ["照片无法判断", vision.uncertain],
    ];
    sections.forEach(([label, items]) => {
      if (!Array.isArray(items) || !items.length) return;
      const section = el("div", "vision-section");
      section.appendChild(el("strong", "", label));
      const list = el("ul");
      items.forEach((item) => list.appendChild(el("li", "", item)));
      section.appendChild(list);
      block.appendChild(section);
    });
    block.appendChild(
      el("p", "vision-note", "视觉模型只描述可见信息，不知道你的操作步骤；不能仅凭照片确定原因。")
    );
    return block;
  }

  function appendFeedback(card, diagId, currentFeedback) {
    const row = el("div", "feedback-row");
    row.appendChild(el("span", "", "这个判断对现场有用吗？"));
    const good = el("button", "feedback-button", "有用");
    const bad = el("button", "feedback-button", "不太对");
    [good, bad].forEach((button) => {
      button.type = "button";
      button.dataset.diagId = String(diagId);
    });
    good.dataset.helpful = "1";
    bad.dataset.helpful = "-1";
    if (currentFeedback === 1) good.classList.add("is-selected");
    if (currentFeedback === -1) bad.classList.add("is-selected");
    good.addEventListener("click", () => submitFeedback(diagId, true, row));
    bad.addEventListener("click", () => submitFeedback(diagId, false, row));
    append(row, good, bad);
    card.appendChild(row);
  }

  async function submitFeedback(diagId, helpful, row) {
    const buttons = $$(".feedback-button", row);
    buttons.forEach((button) => {
      button.disabled = true;
    });
    try {
      await api(`/api/diagnoses/${diagId}/feedback`, {
        method: "POST",
        body: { helpful, note: "" },
      });
      buttons.forEach((button) => {
        button.classList.toggle(
          "is-selected",
          button.dataset.helpful === (helpful ? "1" : "-1")
        );
        button.disabled = false;
      });
      const record = state.records.find((item) => item.id === diagId);
      if (record) {
        record.feedback = helpful ? 1 : -1;
        renderRecords();
      }
      showToast("已记录你的反馈。");
    } catch (error) {
      buttons.forEach((button) => {
        button.disabled = false;
      });
      showToast(error.message || "反馈没有保存成功。", true);
    }
  }

  // -----------------------------------------------------------------------
  // 问诊记录
  // -----------------------------------------------------------------------

  async function loadRecords(force = false) {
    if (state.recordsLoading) return;
    if (state.recordsLoaded && !force) {
      renderRecords();
      return;
    }
    state.recordsLoading = true;
    const list = $("#records-list");
    showInlineLoading(list, "正在读取问诊记录…");
    try {
      const data = await api("/api/diagnoses?limit=100");
      state.records = data.items || [];
      state.recordStats = data.stats || null;
      state.recordsLoaded = true;
      renderRecords();
    } catch (error) {
      clear(list);
      const empty = el("div", "empty-state");
      append(empty, el("h4", "", "记录没有读取成功"), el("p", "", error.message || "请稍后重试。"));
      list.appendChild(empty);
      showToast(error.message || "记录读取失败。", true);
    } finally {
      state.recordsLoading = false;
    }
  }

  function renderRecords() {
    const stats = $("#record-stats");
    const list = $("#records-list");
    if (!stats || !list) return;
    const data = state.recordStats || { total: 0, week: 0, helpful_rate: null };
    clear(stats);
    [
      [String(data.total ?? 0), "全部问诊"],
      [String(data.week ?? 0), "近 7 天"],
      [data.helpful_rate === null || data.helpful_rate === undefined ? "—" : `${data.helpful_rate}%`, "反馈有用率"],
    ].forEach(([value, label]) => {
      const box = el("div", "stat-box");
      append(box, el("strong", "", value), el("span", "", label));
      stats.appendChild(box);
    });

    clear(list);
    if (!state.records.length) {
      const empty = el("div", "empty-state");
      append(
        empty,
        el("h4", "", "还没有问诊记录"),
        el("p", "", "在排查页描述一次现象，记录会自动保存在这里。")
      );
      const go = el("button", "secondary-button", "去排查");
      go.type = "button";
      go.addEventListener("click", () => navigate("diagnose"));
      empty.appendChild(go);
      list.appendChild(empty);
      return;
    }

    state.records.forEach((record) => {
      const button = el("button", "record-card");
      button.type = "button";
      button.dataset.recordId = String(record.id);
      const date = formatRecordDate(record.created_at);
      const dateBox = el("div", "record-date");
      append(dateBox, el("strong", "", date.top), el("span", "", date.bottom));
      const main = el("div", "record-main");
      append(main, el("h4", "", record.query || "未填写问题"));
      const meta = [
        record.experiment_name || "未匹配实验",
        record.step || record.symptom || "",
      ]
        .filter(Boolean)
        .join(" · ");
      append(main, el("p", "", meta));
      const tail = el("div", "record-tail");
      tail.appendChild(el("span", "confidence-small", record.confidence ? `${record.confidence}` : "—"));
      if (record.feedback === 1) tail.appendChild(el("span", "feedback-mark", "有用"));
      if (record.feedback === -1) tail.appendChild(el("span", "feedback-mark is-negative", "不对"));
      append(button, dateBox, main, tail);
      list.appendChild(button);
    });
  }

  async function openRecord(recordId) {
    openSheet("问诊记录", (body) => {
      showInlineLoading(body, "正在读取完整记录…");
    });
    try {
      const item = await api(`/api/diagnoses/${recordId}`);
      headlineSheet(`问诊记录 · ${item.experiment_name || "未匹配实验"}`);
      const body = $("#sheet-body");
      clear(body);
      body.scrollTop = 0;
      const queryBlock = el("div", "panel-card");
      const heading = el("div", "panel-heading");
      const headingText = el("div");
      append(headingText, el("p", "eyebrow", "QUESTION"), el("h3", "", "当时的问题"));
      heading.appendChild(headingText);
      const meta = el("p", "sheet-intro");
      meta.textContent = [
        formatDateTime(item.created_at),
        item.experiment_name,
        item.step,
      ]
        .filter(Boolean)
        .join(" · ");
      append(queryBlock, heading, meta, el("p", "result-summary", item.query || ""));
      body.appendChild(queryBlock);
      const host = el("div");
      renderAnswer(host, item.answer || {}, { diagId: item.id, feedback: item.feedback });
      body.appendChild(host);
    } catch (error) {
      const body = $("#sheet-body");
      clear(body);
      const box = el("div", "empty-state");
      append(box, el("h4", "", "记录读取失败"), el("p", "", error.message || "请稍后重试。"));
      body.appendChild(box);
    }
  }

  // -----------------------------------------------------------------------
  // 账户
  // -----------------------------------------------------------------------

  function openAccountSheet() {
    openSheet("账户", (body) => {
      const user = state.user;
      const head = el("div", "account-sheet-head");
      const avatar = el("div", "avatar-large", avatarText(user.display_name || user.username, user.role));
      const copy = el("div");
      append(copy, el("h3", "", user.display_name || user.username), el("p", "", `@${user.username} · ${roleLabel(user.role)}`));
      head.append(avatar, copy);
      body.appendChild(head);

      const rows = el("div", "account-rows");
      [
        ["学号 / 工号", user.student_no || "未填写"],
        ["班级", user.class_name || "未填写"],
        ["上次登录", user.last_login_at ? formatDateTime(user.last_login_at) : "首次登录"],
      ].forEach(([label, value]) => {
        const row = el("div", "account-row");
        append(row, el("span", "", label), el("strong", "", value));
        rows.appendChild(row);
      });
      body.appendChild(rows);

      if (user.must_change_password) {
        body.appendChild(
          el("p", "result-warning", "你仍在使用初始密码。建议现在修改，避免账号被同组同学误用。")
        );
      }

      const actions = el("div", "sheet-actions");
      const edit = el("button", "secondary-button", "编辑资料");
      const password = el("button", "secondary-button", "修改密码");
      const logout = el("button", "ghost-danger-button", "退出登录");
      edit.type = password.type = logout.type = "button";
      edit.addEventListener("click", openEditProfileSheet);
      password.addEventListener("click", openChangePasswordSheet);
      logout.addEventListener("click", () => {
        closeSheet();
        logoutUser();
      });
      append(actions, edit, password, logout);
      body.appendChild(actions);
    });
  }

  function openEditProfileSheet() {
    openSheet("编辑资料", (body) => {
      const user = state.user;
      body.appendChild(el("p", "sheet-intro", "登录账号不可修改。显示名称会出现在问诊记录和管理后台。"));
      const form = el("form", "stack-form");
      form.noValidate = true;
      const displayField = buildField("显示名称", "text", user.display_name || "", "profile-display");
      displayField.input.maxLength = 40;
      const numberField = buildField("学号 / 工号（可选）", "text", user.student_no || "", "profile-student-no");
      numberField.input.maxLength = 40;
      const classField = buildField("班级（可选）", "text", user.class_name || "", "profile-class");
      classField.input.maxLength = 80;
      const error = el("p", "form-error");
      error.hidden = true;
      const actions = el("div", "form-inline-actions");
      const cancel = el("button", "secondary-button", "取消");
      const save = el("button", "primary-button compact-button", "保存");
      cancel.type = "button";
      save.type = "submit";
      cancel.addEventListener("click", closeSheet);
      actions.append(cancel, save);
      append(form, displayField.field, numberField.field, classField.field, error, actions);
      body.appendChild(form);

      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        setFormError(error, "");
        if (!displayField.input.value.trim()) {
          setFormError(error, "显示名称不能为空。");
          displayField.input.focus();
          return;
        }
        setButtonBusy(save, true, "保存中…");
        try {
          const data = await api("/api/profile", {
            method: "PUT",
            body: {
              display_name: displayField.input.value.trim(),
              student_no: numberField.input.value.trim(),
              class_name: classField.input.value.trim(),
            },
          });
          state.user = { ...state.user, ...data.user };
          updateUserChrome();
          closeSheet();
          showToast("资料已更新。");
        } catch (err) {
          setFormError(error, err.message || "保存失败。");
        } finally {
          setButtonBusy(save, false);
        }
      });
    });
  }

  function openChangePasswordSheet() {
    openSheet("修改密码", (body) => {
      body.appendChild(el("p", "sheet-intro", "至少 8 位，首尾不要有空格。修改后下次登录请使用新密码。"));
      const form = el("form", "stack-form");
      form.noValidate = true;
      const current = buildField("当前密码", "password", "", "sheet-current-password");
      const next = buildField("新密码", "password", "", "sheet-new-password");
      const confirm = buildField("再输一次", "password", "", "sheet-confirm-password");
      current.input.autocomplete = "current-password";
      next.input.autocomplete = "new-password";
      confirm.input.autocomplete = "new-password";
      const error = el("p", "form-error");
      error.hidden = true;
      const save = el("button", "primary-button", "更新密码");
      save.type = "submit";
      append(form, current.field, next.field, confirm.field, error, save);
      body.appendChild(form);

      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        setFormError(error, "");
        if (!current.input.value || next.input.value.length < 8) {
          setFormError(error, "请填写当前密码，新密码至少 8 位。");
          return;
        }
        if (next.input.value !== confirm.input.value) {
          setFormError(error, "两次输入的新密码不一致。");
          confirm.input.focus();
          return;
        }
        setButtonBusy(save, true, "更新中…");
        try {
          await api("/api/profile/password", {
            method: "POST",
            body: {
              current_password: current.input.value,
              new_password: next.input.value,
            },
          });
          state.user.must_change_password = false;
          updateUserChrome();
          closeSheet();
          showToast("密码已更新。");
        } catch (err) {
          setFormError(error, err.message || "修改失败。");
        } finally {
          setButtonBusy(save, false);
        }
      });
    });
  }

  async function handlePagePassword(event) {
    event.preventDefault();
    const current = $("#current-password");
    const next = $("#new-password");
    const confirm = $("#confirm-password");
    const error = $("#password-error");
    setFormError(error, "");
    if (!current.value || next.value.length < 8) {
      setFormError(error, "请填写当前密码，新密码至少 8 位。");
      return;
    }
    if (next.value !== confirm.value) {
      setFormError(error, "两次输入的新密码不一致。");
      confirm.focus();
      return;
    }
    const button = event.submitter;
    if (button) setButtonBusy(button, true, "更新中…");
    try {
      await api("/api/profile/password", {
        method: "POST",
        body: { current_password: current.value, new_password: next.value },
      });
      current.value = next.value = confirm.value = "";
      state.user.must_change_password = false;
      updateUserChrome();
      showToast("密码已更新。");
    } catch (err) {
      setFormError(error, err.message || "修改失败。");
    } finally {
      if (button) setButtonBusy(button, false);
    }
  }

  async function logoutUser() {
    try {
      await api("/api/logout", { method: "POST" });
    } catch {
      // 会话已经失效时也直接回登录页。
    }
    window.location.replace("/login");
  }

  function buildField(labelText, type, value, id) {
    const field = el("div", "field");
    const label = el("label", "", labelText);
    label.htmlFor = id;
    const input = document.createElement("input");
    input.type = type;
    input.id = id;
    input.value = value || "";
    append(field, label, input);
    return { field, input };
  }

  // -----------------------------------------------------------------------
  // 管理端
  // -----------------------------------------------------------------------

  async function loadAdmin(force = false) {
    if (state.adminLoading) return;
    if (state.adminLoaded && !force) {
      renderAdmin();
      return;
    }
    state.adminLoading = true;
    setAdminLoadingState();
    try {
      if (!state.experiments.length) await loadExperiments();
      const [overview, users, ops] = await Promise.all([
        api("/api/admin/overview"),
        api("/api/admin/users"),
        api("/api/admin/operations"),
      ]);
      state.adminOverview = overview;
      state.adminUsers = users.items || [];
      state.adminOps = ops.items || [];
      state.adminLoaded = true;
      renderAdmin();
    } catch (error) {
      showToast(error.message || "管理数据读取失败。", true);
      renderAdminError(error.message || "管理数据读取失败。");
    } finally {
      state.adminLoading = false;
    }
  }

  function setAdminLoadingState() {
    const stats = $("#admin-stats");
    if (stats) {
      clear(stats);
      for (let i = 0; i < 4; i += 1) {
        const box = el("div", "admin-stat");
        append(box, el("strong", "", "…"), el("span", "", "读取中"));
        stats.appendChild(box);
      }
    }
    const ops = $("#ops-list");
    if (ops && !ops.childElementCount) showInlineLoading(ops, "正在读取操作数据…");
    const users = $("#users-list");
    if (users && !users.childElementCount) showInlineLoading(users, "正在读取用户库…");
  }

  function renderAdmin() {
    renderAdminStats();
    renderAdminEngine();
    renderAdminRecent();
    renderAdminTopQueries();
    renderOpsList();
    renderUsersList();
    setAdminTab(state.adminTab);
  }

  function renderAdminError(message) {
    const stats = $("#admin-stats");
    clear(stats);
    const box = el("div", "empty-state");
    append(box, el("h4", "", "管理数据没有读取成功"), el("p", "", message));
    stats.appendChild(box);
  }

  function renderAdminStats() {
    const stats = $("#admin-stats");
    if (!stats) return;
    clear(stats);
    const data = state.adminOverview?.stats || {};
    const items = [
      [String(data.users ?? 0), `用户库 · 启用 ${data.active_users ?? 0}`],
      [String(data.diagnoses_week ?? 0), "近 7 天问诊"],
      [String(data.standard_ops ?? 0), "标准操作记录"],
      [String(data.error_ops ?? 0), "误差操作记录"],
    ];
    items.forEach(([value, label]) => {
      const box = el("div", "admin-stat");
      append(box, el("strong", "", value), el("span", "", label));
      stats.appendChild(box);
    });
  }

  function renderAdminEngine() {
    const engine = state.adminOverview?.engine || state.engine || {};
    const model = $("#engine-model");
    const note = $("#engine-note");
    const dot = $("#engine-dot");
    if (model) model.textContent = `${engine.agent_name || "chem"} · ${friendlyModel(engine.model) || "未配置模型"}`;
    if (note) {
      if (!engine.configured) {
        note.textContent = "没有配置 chem 引擎，排障会退回本地知识库。";
      } else if (engine.backend === "direct") {
        note.textContent = `已配置直连模型 API（${engine.provider || "DeepSeek API"}）。点下方按钮实际调用一次确认连通。`;
      } else {
        note.textContent = "已读取 Cherry Studio 中 chem 的模型与设定。点下方按钮实际调用一次确认连通。";
      }
      const vision = state.adminOverview?.stats?.vision;
      if (vision) {
        note.textContent += vision.configured
          ? ` 图片识别：${vision.provider || "Qwen3-VL"} · ${friendlyModel(vision.model)}。`
          : " 图片识别：未配置 VISION_API_KEY。";
      }
    }
    if (dot) {
      dot.classList.toggle("is-online", Boolean(engine.configured));
      dot.classList.toggle("is-offline", !engine.configured);
    }
  }

  function renderAdminRecent() {
    const container = $("#admin-recent-runs");
    if (!container) return;
    clear(container);
    const recent = state.adminOverview?.recent || [];
    if (!recent.length) {
      const empty = el("div", "empty-state");
      append(empty, el("h4", "", "还没有问诊"), el("p", "", "学生提交排查后，记录会出现在这里。"));
      container.appendChild(empty);
      return;
    }
    recent.forEach((item) => {
      const row = el("div", "recent-run");
      row.appendChild(el("span", "recent-run-time", formatShort(item.created_at)));
      const copy = el("div", "recent-run-copy");
      append(copy, el("p", "", item.query || "未填写问题"));
      append(
        copy,
        el(
          "span",
          "",
          [item.user_name || item.username, item.experiment_name || "未匹配实验", item.step]
            .filter(Boolean)
            .join(" · ")
        )
      );
      row.appendChild(copy);
      container.appendChild(row);
    });
  }

  function renderAdminTopQueries() {
    const container = $("#admin-top-queries");
    if (!container) return;
    clear(container);
    const queries = state.adminOverview?.stats?.top_queries || [];
    if (!queries.length) {
      container.appendChild(el("p", "sheet-intro", "数据还不够，暂时没有高频问题。"));
      return;
    }
    queries.forEach((item, index) => {
      const row = el("div", "top-query");
      append(
        row,
        el("span", "top-query-index", String(index + 1).padStart(2, "0")),
        el("p", "", item.query),
        el("span", "", `${item.n} 次`)
      );
      container.appendChild(row);
    });
  }

  function setAdminTab(tab) {
    state.adminTab = ["ops", "users", "runs"].includes(tab) ? tab : "ops";
    $$(".admin-tab").forEach((button) => {
      const active = button.dataset.adminTab === state.adminTab;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
    });
    ["ops", "users", "runs"].forEach((name) => {
      const panel = $(`#admin-panel-${name}`);
      if (panel) panel.hidden = name !== state.adminTab;
    });
    if (state.adminTab === "ops") renderOpsList();
    if (state.adminTab === "users") renderUsersList();
  }

  function getSelectedOpFilters() {
    return {
      experiment: $("#ops-filter-experiment")?.value || "",
      kind: $("#ops-filter-kind")?.value || "",
    };
  }

  function renderOpsList() {
    const list = $("#ops-list");
    if (!list) return;
    const filters = getSelectedOpFilters();
    const items = state.adminOps.filter((op) => {
      if (filters.experiment && op.experiment_id !== filters.experiment) return false;
      if (filters.kind && op.kind !== filters.kind) return false;
      return true;
    });
    const count = $("#ops-count");
    if (count) {
      count.textContent = `共 ${state.adminOps.length} 条记录 · 当前显示 ${items.length} 条`;
    }
    clear(list);
    if (!items.length) {
      const empty = el("div", "empty-state");
      append(empty, el("h4", "", "当前筛选下没有记录"), el("p", "", "调整筛选，或在上面的表单新增一条。"));
      list.appendChild(empty);
      return;
    }
    items.forEach((op) => {
      const card = el("div", "op-card");
      const head = el("div", "op-card-head");
      const title = el("div", "op-card-title");
      const titleLine = el("h4", "", op.title);
      append(
        title,
        titleLine,
        el("p", "", [op.experiment_name, op.step].filter(Boolean).join(" · "))
      );
      const actions = el("div", "op-card-actions");
      const edit = el("button", "op-mini-button", "编辑");
      const remove = el("button", "op-mini-button is-danger", "删除");
      edit.type = remove.type = "button";
      edit.dataset.opAction = "edit";
      remove.dataset.opAction = "delete";
      edit.dataset.opId = String(op.id);
      remove.dataset.opId = String(op.id);
      append(actions, edit, remove);
      append(head, title, actions);
      card.appendChild(head);

      const kindTag = el("span", op.kind === "standard" ? "op-kind-tag" : "op-kind-tag is-error", op.kind === "standard" ? "标准操作" : "误差操作");
      const metaLine = el("div", "op-summary");
      metaLine.appendChild(kindTag);
      const facts =
        op.kind === "standard"
          ? [op.conditions, op.expected].filter(Boolean).join(" / ")
          : [op.observed, op.deviation, op.cause].filter(Boolean).join(" / ");
      if (facts) {
        const p = el("p");
        p.textContent = facts;
        metaLine.appendChild(p);
      }
      if (op.source) {
        const p = el("p");
        p.appendChild(el("span", "", "来源："));
        p.appendChild(document.createTextNode(op.source));
        metaLine.appendChild(p);
      }
      card.appendChild(metaLine);
      list.appendChild(card);
    });
  }

  function renderUsersList() {
    const list = $("#users-list");
    if (!list) return;
    const count = $("#users-count");
    if (count) {
      const active = state.adminUsers.filter((user) => user.is_active).length;
      count.textContent = `共 ${state.adminUsers.length} 个账号 · ${active} 个启用`;
    }
    clear(list);
    if (!state.adminUsers.length) {
      const empty = el("div", "empty-state");
      append(empty, el("h4", "", "还没有用户"), el("p", "", "用上面的表单创建第一个账号。"));
      list.appendChild(empty);
      return;
    }
    state.adminUsers.forEach((user) => {
      const card = el("div", "user-card");
      const top = el("div", "user-top");
      const avatar = el("div", "user-avatar", avatarText(user.display_name || user.username, user.role));
      const copy = el("div", "user-copy");
      const name = el("h4");
      name.appendChild(document.createTextNode(user.display_name || user.username));
      name.appendChild(el("span", user.role === "admin" ? "user-role is-admin" : "user-role", roleLabel(user.role)));
      name.appendChild(el("span", user.is_active ? "user-status" : "user-status is-off", user.is_active ? "启用" : "停用"));
      append(
        copy,
        name,
        el(
          "p",
          "",
          [`@${user.username}`, user.student_no, user.class_name].filter(Boolean).join(" · ")
        )
      );
      append(top, avatar, copy);
      card.appendChild(top);

      const meta = el("div", "op-summary");
      const p = el("p");
      p.appendChild(el("span", "", "上次登录："));
      p.appendChild(document.createTextNode(user.last_login_at ? formatDateTime(user.last_login_at) : "从未登录"));
      const p2 = el("p");
      p2.appendChild(el("span", "", "问诊记录："));
      p2.appendChild(document.createTextNode(`${user.diagnosis_count || 0} 条`));
      append(meta, p, p2);
      card.appendChild(meta);

      const actions = el("div", "user-actions");
      const edit = el("button", "op-mini-button", "编辑资料");
      const reset = el("button", "op-mini-button", "重置密码");
      const toggle = el("button", "op-mini-button", user.is_active ? "停用账号" : "启用账号");
      edit.type = reset.type = toggle.type = "button";
      edit.dataset.userAction = "edit";
      reset.dataset.userAction = "reset";
      toggle.dataset.userAction = "toggle";
      [edit, reset, toggle].forEach((button) => {
        button.dataset.userId = String(user.id);
      });
      append(actions, edit, reset, toggle);
      card.appendChild(actions);
      list.appendChild(card);
    });
  }

  function resetOpForm() {
    state.opEditingId = null;
    $("#op-id").value = "";
    $("#op-title").value = "";
    $("#op-step").value = "";
    $("#op-experiment").value = "";
    $("#op-conditions").value = "";
    $("#op-expected").value = "";
    $("#op-observed").value = "";
    $("#op-deviation").value = "";
    $("#op-cause").value = "";
    $("#op-severity").value = "";
    $("#op-source").value = "";
    setOpKind("standard");
    $("#op-edit-badge").hidden = true;
    $("#op-form-title").textContent = "新增操作数据";
    $("#op-submit").textContent = "保存记录";
    setFormError($("#op-error"), "");
    updateStepOptions();
  }

  function setOpKind(kind) {
    state.opKind = kind === "error" ? "error" : "standard";
    $$(".kind-button").forEach((button) => {
      button.classList.toggle("is-active", button.dataset.kind === state.opKind);
    });
    $("#standard-fields").hidden = state.opKind !== "standard";
    $("#error-fields").hidden = state.opKind !== "error";
  }

  function updateStepOptions() {
    const expId = $("#op-experiment")?.value;
    const list = $("#op-step-list");
    if (!list) return;
    clear(list);
    const exp = state.experimentsById.get(expId);
    if (!exp) return;
    (exp.steps || []).forEach((step) => {
      const option = document.createElement("option");
      option.value = step.name;
      list.appendChild(option);
    });
  }

  function editOperation(opId) {
    const op = state.adminOps.find((item) => item.id === opId);
    if (!op) return;
    state.opEditingId = op.id;
    $("#op-id").value = String(op.id);
    $("#op-experiment").value = op.experiment_id;
    $("#op-step").value = op.step || "";
    $("#op-title").value = op.title || "";
    $("#op-conditions").value = op.conditions || "";
    $("#op-expected").value = op.expected || "";
    $("#op-observed").value = op.observed || "";
    $("#op-deviation").value = op.deviation || "";
    $("#op-cause").value = op.cause || "";
    $("#op-severity").value = op.severity || "";
    $("#op-source").value = op.source || "";
    setOpKind(op.kind);
    updateStepOptions();
    $("#op-edit-badge").hidden = false;
    $("#op-form-title").textContent = "编辑操作数据";
    $("#op-submit").textContent = "保存修改";
    setFormError($("#op-error"), "");
    $("#op-form").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function handleOperationSubmit(event) {
    event.preventDefault();
    const error = $("#op-error");
    setFormError(error, "");
    const experimentId = $("#op-experiment").value;
    const title = $("#op-title").value.trim();
    if (!experimentId) {
      setFormError(error, "先选择实验。");
      $("#op-experiment").focus();
      return;
    }
    if (!title) {
      setFormError(error, "给这条记录写一个标题。");
      $("#op-title").focus();
      return;
    }
    if (state.opKind === "standard" && !$("#op-conditions").value.trim() && !$("#op-expected").value.trim()) {
      setFormError(error, "标准操作至少填写条件或预期结果。");
      return;
    }
    if (state.opKind === "error" && !$("#op-observed").value.trim() && !$("#op-deviation").value.trim() && !$("#op-cause").value.trim()) {
      setFormError(error, "误差操作至少填写实际现象、偏差影响或原因。");
      return;
    }

    const payload = {
      experiment_id: experimentId,
      step: $("#op-step").value.trim(),
      kind: state.opKind,
      title,
      conditions: $("#op-conditions").value.trim(),
      expected: $("#op-expected").value.trim(),
      observed: $("#op-observed").value.trim(),
      deviation: $("#op-deviation").value.trim(),
      cause: $("#op-cause").value.trim(),
      severity: $("#op-severity").value,
      source: $("#op-source").value.trim(),
    };
    const submit = $("#op-submit");
    setButtonBusy(submit, true, "保存中…");
    try {
      if (state.opEditingId) {
        await api(`/api/admin/operations/${state.opEditingId}`, { method: "PUT", body: payload });
        showToast("操作数据已更新。");
      } else {
        await api("/api/admin/operations", { method: "POST", body: payload });
        showToast("操作数据已保存。");
      }
      resetOpForm();
      await reloadAfterDataChange();
    } catch (err) {
      setFormError(error, err.message || "保存失败。");
    } finally {
      submit.disabled = false;
      delete submit.dataset.originalText;
      submit.textContent = state.opEditingId ? "保存修改" : "保存记录";
    }
  }

  async function deleteOperation(opId) {
    const op = state.adminOps.find((item) => item.id === opId);
    if (!op) return;
    if (!window.confirm(`删除「${op.title}」？删除后，新的排查不会再引用这条数据。`)) return;
    try {
      await api(`/api/admin/operations/${opId}`, { method: "DELETE" });
      showToast("记录已删除。");
      await reloadAfterDataChange();
    } catch (error) {
      showToast(error.message || "删除失败。", true);
    }
  }

  async function reloadAfterDataChange() {
    try {
      await loadExperiments(true);
    } catch (error) {
      showToast(error.message || "实验库刷新失败。", true);
    }
    try {
      await loadAdmin(true);
    } catch (error) {
      showToast(error.message || "管理数据刷新失败。", true);
    }
    const route = parseHash();
    if (route.view === "library" && route.detailId) {
      renderExperimentDetail(route.detailId);
    }
  }

  async function handleCreateUser(event) {
    event.preventDefault();
    const error = $("#user-form-error");
    setFormError(error, "");
    const username = $("#new-username").value.trim();
    const displayName = $("#new-display-name").value.trim();
    const password = $("#create-user-password").value;
    if (!/^[A-Za-z0-9_.-]{3,32}$/.test(username)) {
      setFormError(error, "账号只能用 3~32 位字母、数字、点、下划线或短横线。");
      return;
    }
    if (!displayName) {
      setFormError(error, "填写显示名称。");
      return;
    }
    if (password.length < 8) {
      setFormError(error, "初始密码至少 8 位。");
      return;
    }
    const button = event.submitter;
    if (button) setButtonBusy(button, true, "创建中…");
    try {
      await api("/api/admin/users", {
        method: "POST",
        body: {
          username,
          password,
          display_name: displayName,
          role: $("#new-role").value,
          student_no: $("#new-student-no").value.trim(),
          class_name: $("#new-class-name").value.trim(),
        },
      });
      $("#new-username").value = "";
      $("#new-display-name").value = "";
      $("#create-user-password").value = "";
      $("#new-student-no").value = "";
      $("#new-class-name").value = "";
      $("#new-role").value = "student";
      showToast("账号已创建，首次登录后需要修改密码。");
      await loadAdmin(true);
    } catch (err) {
      setFormError(error, err.message || "创建失败。");
    } finally {
      if (button) setButtonBusy(button, false);
    }
  }

  async function toggleUser(user, makeActive) {
    const action = makeActive ? "启用" : "停用";
    if (!window.confirm(`${action}账号「${user.display_name || user.username}」？${makeActive ? "" : "该账号现有会话会立即退出。"}`)) return;
    try {
      await api(`/api/admin/users/${user.id}`, {
        method: "PATCH",
        body: { is_active: makeActive },
      });
      showToast(`账号已${action}。`);
      await loadAdmin(true);
    } catch (error) {
      showToast(error.message || "操作失败。", true);
    }
  }

  function openUserEditSheet(user) {
    openSheet("编辑用户资料", (body) => {
      body.appendChild(el("p", "sheet-intro", `登录账号 @${user.username} 不可修改。`));
      const form = el("form", "stack-form");
      form.noValidate = true;
      const display = buildField("显示名称", "text", user.display_name || "", "admin-user-display");
      display.input.maxLength = 40;
      const studentNo = buildField("学号 / 工号", "text", user.student_no || "", "admin-user-student-no");
      const className = buildField("班级", "text", user.class_name || "", "admin-user-class");
      const error = el("p", "form-error");
      error.hidden = true;
      const save = el("button", "primary-button", "保存资料");
      save.type = "submit";
      append(form, display.field, studentNo.field, className.field, error, save);
      body.appendChild(form);

      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        setFormError(error, "");
        if (!display.input.value.trim()) {
          setFormError(error, "显示名称不能为空。");
          return;
        }
        setButtonBusy(save, true, "保存中…");
        try {
          const data = await api(`/api/admin/users/${user.id}`, {
            method: "PATCH",
            body: {
              display_name: display.input.value.trim(),
              student_no: studentNo.input.value.trim(),
              class_name: className.input.value.trim(),
            },
          });
          if (user.id === state.user.id) {
            state.user = { ...state.user, ...data.user };
            updateUserChrome();
          }
          closeSheet();
          showToast("用户资料已更新。");
          await loadAdmin(true);
        } catch (err) {
          setFormError(error, err.message || "保存失败。");
        } finally {
          setButtonBusy(save, false);
        }
      });
    });
  }

  function openResetPasswordSheet(user) {
    openSheet("重置密码", (body) => {
      body.appendChild(
        el("p", "sheet-intro", `为 ${user.display_name || user.username}（@${user.username}）设置新的初始密码。对方下次登录后建议再次修改。`)
      );
      const form = el("form", "stack-form");
      form.noValidate = true;
      const password = buildField("新密码", "password", "", "admin-reset-password");
      password.input.autocomplete = "new-password";
      const error = el("p", "form-error");
      error.hidden = true;
      const save = el("button", "primary-button", "重置密码");
      save.type = "submit";
      append(form, password.field, error, save);
      body.appendChild(form);

      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        setFormError(error, "");
        if (password.input.value.length < 8) {
          setFormError(error, "密码至少 8 位。");
          password.input.focus();
          return;
        }
        setButtonBusy(save, true, "重置中…");
        try {
          await api(`/api/admin/users/${user.id}`, {
            method: "PATCH",
            body: { new_password: password.input.value },
          });
          closeSheet();
          showToast("密码已重置。");
          await loadAdmin(true);
        } catch (err) {
          setFormError(error, err.message || "重置失败。");
        } finally {
          setButtonBusy(save, false);
        }
      });
    });
  }

  async function testEngine() {
    const button = $("#test-engine");
    const result = $("#engine-test-result");
    const dot = $("#engine-dot");
    setButtonBusy(button, true, "正在调用 chem…");
    if (result) {
      result.classList.remove("is-error");
      result.textContent = "正在发起一次真实模型调用…";
    }
    try {
      const data = await api("/api/admin/engine/test", { method: "POST" });
      const outcome = data.result || {};
      if (outcome.ok) {
        if (dot) {
          dot.classList.remove("is-offline");
          dot.classList.add("is-online");
        }
        if (result) result.textContent = `连接正常 · ${outcome.elapsed_ms || 0} ms`;
        showToast("chem 引擎调用正常。");
      } else {
        if (dot) {
          dot.classList.remove("is-online");
          dot.classList.add("is-offline");
        }
        if (result) {
          result.classList.add("is-error");
          result.textContent = outcome.message || "调用失败。";
        }
        showToast(outcome.message || "chem 引擎调用失败。", true);
      }
    } catch (error) {
      if (dot) {
        dot.classList.remove("is-online");
        dot.classList.add("is-offline");
      }
      if (result) {
        result.classList.add("is-error");
        result.textContent = error.message || "调用失败。";
      }
      showToast(error.message || "chem 引擎调用失败。", true);
    } finally {
      setButtonBusy(button, false);
    }
  }

  // -----------------------------------------------------------------------
  // Sheet
  // -----------------------------------------------------------------------

  function openSheet(title, builder) {
    const backdrop = $("#sheet-backdrop");
    headlineSheet(title);
    const body = $("#sheet-body");
    clear(body);
    builder(body);
    body.scrollTop = 0;
    backdrop.hidden = false;
    document.body.classList.add("sheet-open");
    window.setTimeout(() => {
      const focusable = body.querySelector("input, select, textarea");
      (focusable || $("#sheet-close")).focus({ preventScroll: true });
    }, 60);
  }

  function headlineSheet(title) {
    $("#sheet-title").textContent = title;
  }

  function closeSheet() {
    const backdrop = $("#sheet-backdrop");
    if (!backdrop || backdrop.hidden) return;
    backdrop.hidden = true;
    document.body.classList.remove("sheet-open");
    clear($("#sheet-body"));
  }

  // -----------------------------------------------------------------------
  // 事件绑定
  // -----------------------------------------------------------------------

  function bindEvents() {
    $$("[data-nav]").forEach((button) => {
      button.addEventListener("click", () => navigate(button.dataset.nav));
    });
    $("#brand-home").addEventListener("click", () => navigate("diagnose"));
    $("#account-button").addEventListener("click", openAccountSheet);

    window.addEventListener("hashchange", () => applyRoute(parseHash()));

    $("#sheet-close").addEventListener("click", closeSheet);
    $("#sheet-backdrop").addEventListener("click", (event) => {
      if (event.target === $("#sheet-backdrop")) closeSheet();
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") closeSheet();
    });

    const query = $("#query");
    query.addEventListener("input", () => {
      $("#query-count").textContent = `${query.value.length} / 1000`;
      setFormError($("#diagnose-error"), "");
    });

    const photoInput = $("#photo-input");
    $("#photo-add").addEventListener("click", () => photoInput.click());
    photoInput.addEventListener("change", () => {
      const file = photoInput.files && photoInput.files[0];
      if (file) handlePhotoFile(file);
    });
    $("#photo-remove").addEventListener("click", clearPhoto);

    $("#quick-prompts").addEventListener("click", (event) => {
      const button = event.target.closest("[data-prompt]");
      if (!button) return;
      $("#query").value = button.dataset.prompt || "";
      $("#query-count").textContent = `${$("#query").value.length} / 1000`;
      const expId = button.dataset.experimentId;
      if (expId) $("#experiment-select").value = expId;
      navigate("diagnose");
      window.setTimeout(() => {
        $("#query").focus();
        $("#query").setSelectionRange($("#query").value.length, $("#query").value.length);
      }, 80);
    });

    $("#home-experiments").addEventListener("click", (event) => {
      const button = event.target.closest("[data-exp-id]");
      if (button) openExperiment(button.dataset.expId);
    });

    $("#diagnose-form").addEventListener("submit", handleDiagnose);

    $("#library-search").addEventListener("input", (event) => {
      state.libraryQuery = event.target.value || "";
      window.clearTimeout(state.searchTimer);
      state.searchTimer = window.setTimeout(renderLibrary, 110);
    });

    $("#category-filters").addEventListener("click", (event) => {
      const button = event.target.closest("[data-category]");
      if (!button) return;
      state.libraryCategory = button.dataset.category;
      renderCategoryFilters();
      renderLibrary();
    });

    $("#library-list").addEventListener("click", (event) => {
      const clearButton = event.target.closest("[data-clear-library]");
      if (clearButton) {
        state.libraryQuery = "";
        state.libraryCategory = "全部";
        $("#library-search").value = "";
        renderCategoryFilters();
        renderLibrary();
        return;
      }
      const card = event.target.closest("[data-exp-id]");
      if (card) openExperiment(card.dataset.expId);
    });

    $("#experiment-back").addEventListener("click", () => {
      window.location.hash = "library";
    });

    $("#experiment-detail-content").addEventListener("click", (event) => {
      const button = event.target.closest("[data-symptom]");
      if (!button) return;
      $("#query").value = button.dataset.symptom || "";
      $("#query-count").textContent = `${$("#query").value.length} / 1000`;
      $("#experiment-select").value = button.dataset.expId || "";
      navigate("diagnose");
      window.setTimeout(() => $("#query").focus(), 80);
    });

    $("#records-list").addEventListener("click", (event) => {
      const card = event.target.closest("[data-record-id]");
      if (card) openRecord(card.dataset.recordId);
    });

    $("#password-form").addEventListener("submit", handlePagePassword);
    $("#go-password").addEventListener("click", () => {
      const form = $("#password-form");
      form.scrollIntoView({ behavior: "smooth", block: "center" });
      window.setTimeout(() => $("#current-password").focus(), 300);
    });
    $("#logout-button").addEventListener("click", logoutUser);

    $$(".admin-tab").forEach((button) => {
      button.addEventListener("click", () => setAdminTab(button.dataset.adminTab));
    });

    $$(".kind-button").forEach((button) => {
      button.addEventListener("click", () => setOpKind(button.dataset.kind));
    });

    $("#op-experiment").addEventListener("change", updateStepOptions);
    $("#op-form").addEventListener("submit", handleOperationSubmit);
    $("#op-new-button").addEventListener("click", resetOpForm);
    $("#op-reset").addEventListener("click", resetOpForm);
    $("#ops-filter-experiment").addEventListener("change", renderOpsList);
    $("#ops-filter-kind").addEventListener("change", renderOpsList);
    $("#ops-list").addEventListener("click", (event) => {
      const action = event.target.closest("[data-op-action]");
      if (!action) return;
      const id = Number(action.dataset.opId);
      if (action.dataset.opAction === "edit") editOperation(id);
      if (action.dataset.opAction === "delete") deleteOperation(id);
    });

    $("#user-form").addEventListener("submit", handleCreateUser);
    $("#users-list").addEventListener("click", (event) => {
      const action = event.target.closest("[data-user-action]");
      if (!action) return;
      const id = Number(action.dataset.userId);
      const user = state.adminUsers.find((item) => item.id === id);
      if (!user) return;
      if (action.dataset.userAction === "edit") openUserEditSheet(user);
      if (action.dataset.userAction === "reset") openResetPasswordSheet(user);
      if (action.dataset.userAction === "toggle") toggleUser(user, !user.is_active);
    });

    $("#test-engine").addEventListener("click", testEngine);

    const datalist = document.createElement("datalist");
    datalist.id = "op-step-list";
    document.body.appendChild(datalist);
    $("#op-step").setAttribute("list", "op-step-list");
  }

  document.addEventListener("DOMContentLoaded", init);
})();
