(() => {
  const form = document.getElementById("login-form");
  const roleTabs = Array.from(document.querySelectorAll(".role-tab"));
  const hint = document.getElementById("login-hint");
  const errorBox = document.getElementById("login-error");
  const submit = document.getElementById("login-submit");
  const username = document.getElementById("username");
  const password = document.getElementById("password");
  const toggle = document.getElementById("password-toggle");

  let role = "student";

  function setRole(nextRole) {
    role = nextRole;
    roleTabs.forEach((tab) => {
      const active = tab.dataset.role === role;
      tab.classList.toggle("is-active", active);
      tab.setAttribute("aria-selected", active ? "true" : "false");
    });
    hint.textContent = role === "admin" ? "开发者控制台登录" : "学生账号登录";
    hideError();
  }

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = false;
  }

  function hideError() {
    errorBox.hidden = true;
    errorBox.textContent = "";
  }

  function setBusy(busy) {
    submit.disabled = busy;
    submit.querySelector("span").textContent = busy ? "正在进入…" : "进入实验台";
  }

  roleTabs.forEach((tab) => {
    tab.addEventListener("click", () => setRole(tab.dataset.role));
  });

  toggle.addEventListener("click", () => {
    const visible = password.type === "text";
    password.type = visible ? "password" : "text";
    toggle.textContent = visible ? "显示" : "隐藏";
    toggle.setAttribute("aria-label", visible ? "显示密码" : "隐藏密码");
    password.focus();
  });

  [username, password].forEach((input) => {
    input.addEventListener("input", hideError);
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    hideError();
    const name = username.value.trim();
    const pass = password.value;
    if (!name || !pass) {
      showError("账号和密码都要填写。");
      (name ? password : username).focus();
      return;
    }

    setBusy(true);
    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ username: name, password: pass, role }),
      });
      let data = null;
      try {
        data = await response.json();
      } catch {
        data = null;
      }
      if (!response.ok) {
        showError(data?.error || "登录失败，请稍后再试。");
        setBusy(false);
        password.select();
        return;
      }
      window.location.replace(data?.redirect || "/");
    } catch {
      showError("无法连接本地服务，请确认启动窗口仍然开着。");
      setBusy(false);
    }
  });

  window.setTimeout(() => username.focus(), 80);
})();
