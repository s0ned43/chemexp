@echo off
chcp 65001 >nul
title Lab Bench - Chemistry Lab Diagnosis
cd /d "%~dp0"
echo.
echo   Lab Bench - Chemistry Lab Diagnosis
echo   Starting... the browser will open automatically.
echo   Close this window to stop the server.
echo.
set "UV=uv"
where uv >nul 2>nul
if errorlevel 1 goto find_uv
goto run_app

:find_uv
if exist "C:\Users\dell\.cherrystudio\bin\uv.exe" (
  set "UV=C:\Users\dell\.cherrystudio\bin\uv.exe"
  goto run_app
)
if exist "%USERPROFILE%\.local\bin\uv.exe" (
  set "UV=%USERPROFILE%\.local\bin\uv.exe"
  goto run_app
)
echo uv not found. Install uv first, or contact the developer.
pause
exit /b 1

:run_app
"%UV%" run python app.py
if errorlevel 1 (
  echo.
  echo Failed to start. Screenshot the error above and send it to the developer.
  pause
)
