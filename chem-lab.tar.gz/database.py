# -*- coding: utf-8 -*-
"""SQLite 数据层：账号、会话、问诊记录、操作数据。"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("LAB_DB_PATH", str(BASE / "data" / "app.db")))
SESSION_COOKIE = "lab_session"
SESSION_DAYS = 7

PASSWORD_ITERATIONS = 260_000


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime | None = None) -> str:
    return (dt or utcnow()).isoformat(timespec="seconds")


def local_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def get_conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=12)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


# ---------------------------------------------------------------------------
# 密码与会话
# ---------------------------------------------------------------------------


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS
    )
    return f"pbkdf2_sha256${PASSWORD_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, iterations, salt_hex, digest_hex = encoded.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            bytes.fromhex(salt_hex),
            int(iterations),
        )
        return hmac.compare_digest(digest.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_session(user_id: int, user_agent: str = "") -> tuple[str, str, str]:
    raw_token = secrets.token_urlsafe(32)
    csrf_token = secrets.token_urlsafe(24)
    expires = utcnow() + timedelta(days=SESSION_DAYS)
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO sessions(token_hash, user_id, csrf_token, created_at, expires_at, user_agent) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                _token_hash(raw_token),
                user_id,
                csrf_token,
                iso(),
                iso(expires),
                (user_agent or "")[:300],
            ),
        )
    return raw_token, csrf_token, iso(expires)


def resolve_session(raw_token: str | None) -> dict[str, Any] | None:
    if not raw_token:
        return None
    token_hash = _token_hash(raw_token)
    with get_conn() as conn:
        row = conn.execute(
            """
            SELECT s.csrf_token, s.expires_at, u.id, u.username, u.display_name,
                   u.role, u.student_no, u.class_name, u.is_active,
                   u.must_change_password, u.last_login_at, u.created_at
            FROM sessions s
            JOIN users u ON u.id = s.user_id
            WHERE s.token_hash = ? AND s.expires_at > ?
            """,
            (token_hash, iso()),
        ).fetchone()
    if not row or not row["is_active"]:
        return None
    user = dict(row)
    user["must_change_password"] = bool(user["must_change_password"])
    user["is_active"] = bool(user["is_active"])
    user["csrf_token"] = user.pop("csrf_token")
    user["token_hash"] = token_hash
    return user


def delete_session(raw_token: str | None) -> None:
    if not raw_token:
        return
    with get_conn() as conn:
        conn.execute("DELETE FROM sessions WHERE token_hash = ?", (_token_hash(raw_token),))


def cleanup_sessions() -> None:
    with get_conn() as conn:
        conn.execute("DELETE FROM sessions WHERE expires_at <= ?", (iso(),))


def authenticate(username: str, password: str, role: str) -> dict[str, Any] | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE username = ? COLLATE NOCASE",
            ((username or "").strip(),),
        ).fetchone()
    if not row or not row["is_active"] or row["role"] != role:
        return None
    if not verify_password(password or "", row["password_hash"]):
        return None
    with get_conn() as conn:
        conn.execute("UPDATE users SET last_login_at = ? WHERE id = ?", (local_iso(), row["id"]))
    user = dict(row)
    user.pop("password_hash", None)
    user["must_change_password"] = bool(user["must_change_password"])
    user["is_active"] = bool(user["is_active"])
    return user


# ---------------------------------------------------------------------------
# 用户库
# ---------------------------------------------------------------------------


def get_user(user_id: int) -> dict[str, Any] | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT id, username, display_name, role, student_no, class_name, is_active, "
            "must_change_password, created_at, last_login_at FROM users WHERE id = ?",
            (user_id,),
        ).fetchone()
    if not row:
        return None
    user = dict(row)
    user["is_active"] = bool(user["is_active"])
    user["must_change_password"] = bool(user["must_change_password"])
    return user


def list_users() -> list[dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute(
            """
            SELECT u.id, u.username, u.display_name, u.role, u.student_no, u.class_name,
                   u.is_active, u.must_change_password, u.created_at, u.last_login_at,
                   (SELECT COUNT(*) FROM diagnoses d WHERE d.user_id = u.id) AS diagnosis_count
            FROM users u
            ORDER BY CASE u.role WHEN 'admin' THEN 0 ELSE 1 END, u.id
            """
        ).fetchall()
    users = [dict(r) for r in rows]
    for user in users:
        user["is_active"] = bool(user["is_active"])
        user["must_change_password"] = bool(user["must_change_password"])
    return users


def create_user(
    *,
    username: str,
    password: str,
    display_name: str,
    role: str = "student",
    student_no: str = "",
    class_name: str = "",
    must_change_password: bool = True,
) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO users(username, password_hash, display_name, role, student_no, class_name, "
            "must_change_password, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                username.strip(),
                hash_password(password),
                display_name.strip() or username.strip(),
                role,
                student_no.strip(),
                class_name.strip(),
                1 if must_change_password else 0,
                local_iso(),
            ),
        )
        return int(cur.lastrowid)


def update_user_profile(
    user_id: int, display_name: str, student_no: str, class_name: str
) -> None:
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET display_name = ?, student_no = ?, class_name = ? WHERE id = ?",
            (display_name.strip(), student_no.strip(), class_name.strip(), user_id),
        )


def set_user_password(
    user_id: int, password: str, must_change_password: bool = False
) -> None:
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET password_hash = ?, must_change_password = ? WHERE id = ?",
            (hash_password(password), 1 if must_change_password else 0, user_id),
        )


def set_user_active(user_id: int, active: bool) -> None:
    with get_conn() as conn:
        conn.execute("UPDATE users SET is_active = ? WHERE id = ?", (1 if active else 0, user_id))
        if not active:
            conn.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))


def get_user_password_hash(user_id: int) -> str | None:
    with get_conn() as conn:
        row = conn.execute("SELECT password_hash FROM users WHERE id = ?", (user_id,)).fetchone()
    return row["password_hash"] if row else None


def count_users() -> dict[str, int]:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) AS active FROM users"
        ).fetchone()
    return {"total": int(row["total"] or 0), "active": int(row["active"] or 0)}


# ---------------------------------------------------------------------------
# 操作数据
# ---------------------------------------------------------------------------


def get_operation(op_id: int) -> dict[str, Any] | None:
    with get_conn() as conn:
        row = conn.execute(
            """
            SELECT o.*, u.display_name AS author_name
            FROM operation_records o LEFT JOIN users u ON u.id = o.created_by
            WHERE o.id = ?
            """,
            (op_id,),
        ).fetchone()
    return dict(row) if row else None


def list_operations(
    *, experiment_id: str | None = None, kind: str | None = None, limit: int = 500
) -> list[dict[str, Any]]:
    clauses: list[str] = []
    params: list[Any] = []
    if experiment_id:
        clauses.append("o.experiment_id = ?")
        params.append(experiment_id)
    if kind in {"standard", "error"}:
        clauses.append("o.kind = ?")
        params.append(kind)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    params.append(max(1, min(int(limit), 1000)))
    with get_conn() as conn:
        rows = conn.execute(
            f"""
            SELECT o.*, u.display_name AS author_name
            FROM operation_records o
            LEFT JOIN users u ON u.id = o.created_by
            {where}
            ORDER BY CASE o.kind WHEN 'standard' THEN 0 ELSE 1 END, o.id
            LIMIT ?
            """,
            params,
        ).fetchall()
    return [dict(r) for r in rows]


def create_operation(data: dict[str, Any], user_id: int) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            """
            INSERT INTO operation_records(
                experiment_id, experiment_name, step, kind, title, conditions,
                expected, observed, deviation, cause, severity, source, created_by,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data["experiment_id"],
                data["experiment_name"],
                data.get("step", ""),
                data["kind"],
                data["title"],
                data.get("conditions", ""),
                data.get("expected", ""),
                data.get("observed", ""),
                data.get("deviation", ""),
                data.get("cause", ""),
                data.get("severity", ""),
                data.get("source", ""),
                user_id,
                local_iso(),
                local_iso(),
            ),
        )
        return int(cur.lastrowid)


def update_operation(op_id: int, data: dict[str, Any]) -> None:
    with get_conn() as conn:
        conn.execute(
            """
            UPDATE operation_records SET
                experiment_id = ?, experiment_name = ?, step = ?, kind = ?, title = ?,
                conditions = ?, expected = ?, observed = ?, deviation = ?, cause = ?,
                severity = ?, source = ?, updated_at = ?
            WHERE id = ?
            """,
            (
                data["experiment_id"],
                data["experiment_name"],
                data.get("step", ""),
                data["kind"],
                data["title"],
                data.get("conditions", ""),
                data.get("expected", ""),
                data.get("observed", ""),
                data.get("deviation", ""),
                data.get("cause", ""),
                data.get("severity", ""),
                data.get("source", ""),
                local_iso(),
                op_id,
            ),
        )


def delete_operation(op_id: int) -> None:
    with get_conn() as conn:
        conn.execute("DELETE FROM operation_records WHERE id = ?", (op_id,))


def get_operations_for_engine(experiment_ids: Iterable[str], per_kind: int = 6) -> list[dict[str, Any]]:
    ids = list(dict.fromkeys(x for x in experiment_ids if x))
    if not ids:
        return []
    placeholders = ",".join("?" for _ in ids)
    with get_conn() as conn:
        rows = conn.execute(
            f"""
            SELECT * FROM operation_records
            WHERE experiment_id IN ({placeholders})
            ORDER BY CASE kind WHEN 'standard' THEN 0 ELSE 1 END, id
            """,
            ids,
        ).fetchall()
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in rows:
        grouped.setdefault((row["experiment_id"], row["kind"]), []).append(dict(row))
    result: list[dict[str, Any]] = []
    for exp_id in ids:
        for kind in ("standard", "error"):
            result.extend(grouped.get((exp_id, kind), [])[:per_kind])
    return result


def count_operations() -> dict[str, int]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT kind, COUNT(*) AS n FROM operation_records GROUP BY kind"
        ).fetchall()
    result = {"standard": 0, "error": 0}
    for row in rows:
        result[row["kind"]] = int(row["n"])
    result["total"] = result["standard"] + result["error"]
    return result


# ---------------------------------------------------------------------------
# 管理员上传的知识文档
# ---------------------------------------------------------------------------


def create_knowledge_document(
    *,
    title: str,
    experiment_id: str,
    experiment_name: str,
    step: str,
    source: str,
    content: str,
    chunks: list[str],
    status: str,
    user_id: int,
) -> int:
    now = local_iso()
    with get_conn() as conn:
        cur = conn.execute(
            """
            INSERT INTO knowledge_documents(
                title, experiment_id, experiment_name, step, source, content,
                status, created_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                title.strip(),
                experiment_id.strip(),
                experiment_name.strip(),
                step.strip(),
                source.strip(),
                content,
                status,
                user_id,
                now,
                now,
            ),
        )
        doc_id = int(cur.lastrowid)
        for index, chunk in enumerate(chunks):
            conn.execute(
                "INSERT INTO knowledge_chunks(document_id, chunk_index, text, created_at) "
                "VALUES (?, ?, ?, ?)",
                (doc_id, index, chunk, now),
            )
        return doc_id


def list_knowledge_documents(limit: int = 300) -> list[dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute(
            """
            SELECT d.*, u.display_name AS author_name,
                   (SELECT COUNT(*) FROM knowledge_chunks c WHERE c.document_id = d.id) AS chunk_count
            FROM knowledge_documents d
            LEFT JOIN users u ON u.id = d.created_by
            ORDER BY d.id DESC LIMIT ?
            """,
            (max(1, min(int(limit), 1000)),),
        ).fetchall()
    return [dict(row) for row in rows]


def get_knowledge_document(doc_id: int) -> dict[str, Any] | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM knowledge_documents WHERE id = ?", (doc_id,)
        ).fetchone()
    return dict(row) if row else None


def set_knowledge_document_status(doc_id: int, status: str) -> None:
    if status not in {"draft", "published"}:
        return
    with get_conn() as conn:
        conn.execute(
            "UPDATE knowledge_documents SET status = ?, updated_at = ? WHERE id = ?",
            (status, local_iso(), doc_id),
        )


def delete_knowledge_document(doc_id: int) -> None:
    with get_conn() as conn:
        conn.execute("DELETE FROM knowledge_documents WHERE id = ?", (doc_id,))


def list_published_knowledge_chunks(limit: int = 2000) -> list[dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute(
            """
            SELECT c.id, c.document_id, c.chunk_index, c.text,
                   d.title, d.experiment_id, d.experiment_name, d.step, d.source
            FROM knowledge_chunks c
            JOIN knowledge_documents d ON d.id = c.document_id
            WHERE d.status = 'published'
            ORDER BY d.id DESC, c.chunk_index ASC
            LIMIT ?
            """,
            (max(1, min(int(limit), 5000)),),
        ).fetchall()
    return [dict(row) for row in rows]


def knowledge_document_stats() -> dict[str, int]:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS total, "
            "SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) AS published "
            "FROM knowledge_documents"
        ).fetchone()
    return {
        "total": int(row["total"] or 0),
        "published": int(row["published"] or 0),
    }


# ---------------------------------------------------------------------------
# 问诊记录
# ---------------------------------------------------------------------------


def save_diagnosis(
    *,
    user_id: int,
    query: str,
    experiment_id: str,
    experiment_name: str,
    step: str,
    symptom: str,
    confidence: str,
    engine_name: str,
    engine_mode: str,
    model: str,
    answer: dict[str, Any],
    duration_ms: int,
) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            """
            INSERT INTO diagnoses(
                user_id, query, experiment_id, experiment_name, step, symptom, confidence,
                engine_name, engine_mode, model, answer_json, duration_ms, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                query,
                experiment_id,
                experiment_name,
                step,
                symptom,
                confidence,
                engine_name,
                engine_mode,
                model,
                json.dumps(answer, ensure_ascii=False),
                duration_ms,
                local_iso(),
            ),
        )
        return int(cur.lastrowid)


def _diagnosis_row(row: sqlite3.Row, include_answer: bool = True) -> dict[str, Any]:
    item = dict(row)
    if include_answer:
        try:
            item["answer"] = json.loads(item.pop("answer_json"))
        except (json.JSONDecodeError, TypeError):
            item["answer"] = {}
            item.pop("answer_json", None)
    else:
        item.pop("answer_json", None)
    item["feedback"] = int(item["feedback"]) if item.get("feedback") is not None else None
    return item


def list_diagnoses(
    *, user_id: int | None = None, limit: int = 50, include_answer: bool = False
) -> list[dict[str, Any]]:
    params: list[Any] = []
    where = ""
    if user_id is not None:
        where = "WHERE d.user_id = ?"
        params.append(user_id)
    params.append(max(1, min(int(limit), 200)))
    with get_conn() as conn:
        rows = conn.execute(
            f"""
            SELECT d.*, u.display_name AS user_name, u.username
            FROM diagnoses d JOIN users u ON u.id = d.user_id
            {where}
            ORDER BY d.id DESC LIMIT ?
            """,
            params,
        ).fetchall()
    return [_diagnosis_row(r, include_answer=include_answer) for r in rows]


def get_diagnosis(diag_id: int, user_id: int | None = None) -> dict[str, Any] | None:
    params: list[Any] = [diag_id]
    clause = ""
    if user_id is not None:
        clause = "AND d.user_id = ?"
        params.append(user_id)
    with get_conn() as conn:
        row = conn.execute(
            f"""
            SELECT d.*, u.display_name AS user_name, u.username
            FROM diagnoses d JOIN users u ON u.id = d.user_id
            WHERE d.id = ? {clause}
            """,
            params,
        ).fetchone()
    return _diagnosis_row(row) if row else None


def set_feedback(diag_id: int, user_id: int, helpful: bool, note: str = "") -> None:
    with get_conn() as conn:
        conn.execute(
            "UPDATE diagnoses SET feedback = ?, feedback_note = ? WHERE id = ? AND user_id = ?",
            (1 if helpful else -1, note.strip()[:300], diag_id, user_id),
        )


def user_diagnosis_stats(user_id: int) -> dict[str, Any]:
    week_ago = (utcnow() - timedelta(days=7)).astimezone().isoformat(timespec="seconds")
    with get_conn() as conn:
        row = conn.execute(
            """
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN created_at >= ? THEN 1 ELSE 0 END) AS week_total,
                   SUM(CASE WHEN feedback = 1 THEN 1 ELSE 0 END) AS helpful,
                   SUM(CASE WHEN feedback = -1 THEN 1 ELSE 0 END) AS unhelpful
            FROM diagnoses WHERE user_id = ?
            """,
            (week_ago, user_id),
        ).fetchone()
    total = int(row["total"] or 0)
    rated = int(row["helpful"] or 0) + int(row["unhelpful"] or 0)
    return {
        "total": total,
        "week": int(row["week_total"] or 0),
        "helpful": int(row["helpful"] or 0),
        "helpful_rate": round(int(row["helpful"] or 0) / rated * 100) if rated else None,
    }


def admin_overview_stats() -> dict[str, Any]:
    week_ago = (utcnow() - timedelta(days=7)).astimezone().isoformat(timespec="seconds")
    with get_conn() as conn:
        users = conn.execute(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) AS active FROM users"
        ).fetchone()
        diag = conn.execute(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN created_at >= ? THEN 1 ELSE 0 END) AS week_total FROM diagnoses",
            (week_ago,),
        ).fetchone()
        ops = conn.execute(
            "SELECT SUM(CASE WHEN kind = 'standard' THEN 1 ELSE 0 END) AS standard, "
            "SUM(CASE WHEN kind = 'error' THEN 1 ELSE 0 END) AS errors FROM operation_records"
        ).fetchone()
        top = conn.execute(
            """
            SELECT query, COUNT(*) AS n FROM diagnoses
            WHERE query != ''
            GROUP BY query ORDER BY n DESC, MAX(id) DESC LIMIT 5
            """
        ).fetchall()
    return {
        "users": int(users["total"] or 0),
        "active_users": int(users["active"] or 0),
        "diagnoses": int(diag["total"] or 0),
        "diagnoses_week": int(diag["week_total"] or 0),
        "standard_ops": int(ops["standard"] or 0),
        "error_ops": int(ops["errors"] or 0),
        "top_queries": [dict(r) for r in top],
    }


# ---------------------------------------------------------------------------
# 初始化与种子数据
# ---------------------------------------------------------------------------


SCHEMA = """
CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin', 'student')),
    student_no TEXT NOT NULL DEFAULT '',
    class_name TEXT NOT NULL DEFAULT '',
    is_active INTEGER NOT NULL DEFAULT 1,
    must_change_password INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    last_login_at TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    csrf_token TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    user_agent TEXT NOT NULL DEFAULT '',
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS operation_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    experiment_id TEXT NOT NULL,
    experiment_name TEXT NOT NULL,
    step TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL CHECK(kind IN ('standard', 'error')),
    title TEXT NOT NULL,
    conditions TEXT NOT NULL DEFAULT '',
    expected TEXT NOT NULL DEFAULT '',
    observed TEXT NOT NULL DEFAULT '',
    deviation TEXT NOT NULL DEFAULT '',
    cause TEXT NOT NULL DEFAULT '',
    severity TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT '',
    created_by INTEGER,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(experiment_id, kind, title),
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_ops_exp ON operation_records(experiment_id, kind);

CREATE TABLE IF NOT EXISTS diagnoses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    query TEXT NOT NULL,
    experiment_id TEXT NOT NULL DEFAULT '',
    experiment_name TEXT NOT NULL DEFAULT '',
    step TEXT NOT NULL DEFAULT '',
    symptom TEXT NOT NULL DEFAULT '',
    confidence TEXT NOT NULL DEFAULT '',
    engine_name TEXT NOT NULL DEFAULT 'chem',
    engine_mode TEXT NOT NULL DEFAULT 'local',
    model TEXT NOT NULL DEFAULT '',
    answer_json TEXT NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    feedback INTEGER,
    feedback_note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_diag_user ON diagnoses(user_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_diag_created ON diagnoses(created_at);

CREATE TABLE IF NOT EXISTS knowledge_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    experiment_id TEXT NOT NULL DEFAULT '',
    experiment_name TEXT NOT NULL DEFAULT '',
    step TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft', 'published')),
    created_by INTEGER,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_docs_status ON knowledge_documents(status, id DESC);
CREATE INDEX IF NOT EXISTS idx_docs_exp ON knowledge_documents(experiment_id);

CREATE TABLE IF NOT EXISTS knowledge_chunks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL,
    chunk_index INTEGER NOT NULL,
    text TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(document_id) REFERENCES knowledge_documents(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_chunks_doc ON knowledge_chunks(document_id);
"""


def _seed_users() -> None:
    with get_conn() as conn:
        count = int(conn.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"])
    if count:
        return

    admin_password = os.environ.get("LAB_ADMIN_PASSWORD", "ChemLab@2026")
    student_password = os.environ.get("LAB_STUDENT_PASSWORD", "Lab@2026")
    create_user(
        username="admin",
        password=admin_password,
        display_name="开发者",
        role="admin",
        must_change_password=True,
    )
    create_user(
        username="student",
        password=student_password,
        display_name="示例同学",
        role="student",
        student_no="2026001",
        class_name="化学类 2026 级",
        must_change_password=True,
    )


def _seed_operations(kb: dict[str, Any]) -> None:
    version = str(kb.get("meta", {}).get("version", "1.0"))
    with get_conn() as conn:
        row = conn.execute(
            "SELECT value FROM app_meta WHERE key = 'ops_seed_version'"
        ).fetchone()
    if row and row["value"] == version:
        return

    with get_conn() as conn:
        admin = conn.execute(
            "SELECT id FROM users WHERE role = 'admin' ORDER BY id LIMIT 1"
        ).fetchone()
        admin_id = admin["id"] if admin else None
        inserted = 0
        for exp in kb.get("experiments", []):
            for kind, key in (("standard", "standard_ops"), ("error", "error_ops")):
                for op in exp.get(key, []):
                    try:
                        cur = conn.execute(
                            """
                            INSERT OR IGNORE INTO operation_records(
                                experiment_id, experiment_name, step, kind, title, conditions,
                                expected, observed, deviation, cause, severity, source, created_by,
                                created_at, updated_at
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                exp["id"],
                                exp["name"],
                                op.get("step", ""),
                                kind,
                                op.get("title", "").strip(),
                                op.get("conditions", "").strip(),
                                op.get("expected", "").strip(),
                                op.get("observed", "").strip(),
                                op.get("deviation", "").strip(),
                                op.get("cause", "").strip(),
                                op.get("severity", "").strip(),
                                op.get("source", exp.get("source", "")).strip(),
                                admin_id,
                                local_iso(),
                                local_iso(),
                            ),
                        )
                        inserted += cur.rowcount
                    except sqlite3.IntegrityError:
                        pass
        conn.execute(
            "INSERT INTO app_meta(key, value) VALUES ('ops_seed_version', ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (version,),
        )
    if inserted:
        print(f"[db] 已导入 {inserted} 条标准/误差操作记录")


def init_db(kb: dict[str, Any]) -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with get_conn() as conn:
        conn.executescript(SCHEMA)
    _seed_users()
    _seed_operations(kb)
    cleanup_sessions()
