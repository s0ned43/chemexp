# -*- coding: utf-8 -*-
"""知识库检索与 chem 引擎调用。

chem 引擎支持两种连接方式：
- direct：直连 DeepSeek/OpenAI 兼容 API，生产部署推荐，不需要 Cherry Studio；
- cherry：读取 Cherry Studio 本地 chem 智能体配置，经本地 API 调用，适合本地开发。

两种方式都不可用时，退回本地结构化知识库，界面会明确标注。
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import time
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

import requests

BASE = Path(__file__).resolve().parent
KB_PATH = BASE / "knowledge.json"

PUNCT_RE = re.compile(r"[\s　，。！？、；：,.!?;:'\"“”‘’（）()\[\]{}<>《》\-_\\/|+*=#@~`…·]+")
MIN_MATCH_SCORE = 2.8
VALID_LIKELIHOOD = {"高", "中", "低"}
VALID_CONFIDENCE = {"高", "中", "低"}


def normalize(text: Any) -> str:
    text = unicodedata.normalize("NFKC", str(text or "")).lower()
    return PUNCT_RE.sub("", text)


def bigrams(text: str) -> set[str]:
    if len(text) <= 1:
        return {text} if text else set()
    if len(text) == 2:
        return {text}
    return {text[i : i + 2] for i in range(len(text) - 1)}


def clip(value: Any, limit: int = 500) -> str:
    text = str(value or "").strip()
    return text[:limit]


def as_list(value: Any, limit: int = 6) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        parts = [value]
    elif isinstance(value, (list, tuple)):
        parts = value
    else:
        parts = [value]
    result: list[str] = []
    for part in parts:
        text = clip(part, 400)
        if text and text not in result:
            result.append(text)
        if len(result) >= limit:
            break
    return result


class KnowledgeBase:
    def __init__(self, path: Path = KB_PATH):
        self.path = path
        self.data = json.loads(path.read_text(encoding="utf-8"))
        self.experiments: list[dict[str, Any]] = self.data.get("experiments", [])
        self.by_id = {exp["id"]: exp for exp in self.experiments}
        self.items = self._flatten()

    def _flatten(self) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for exp in self.experiments:
            exp_aliases = [normalize(a) for a in exp.get("aliases", []) if normalize(a)]
            for step in exp.get("steps", []):
                step_aliases = [normalize(a) for a in step.get("aliases", []) if normalize(a)]
                for sym in step.get("symptoms", []):
                    sym_aliases = [normalize(a) for a in sym.get("aliases", []) if normalize(a)]
                    code = f"{exp['id']}/{step['id']}/{sym['id']}"
                    items.append(
                        {
                            "code": code,
                            "exp_id": exp["id"],
                            "exp_name": exp["name"],
                            "exp_aliases": exp_aliases,
                            "step_id": step["id"],
                            "step_name": step["name"],
                            "step_aliases": step_aliases,
                            "symptom_id": sym["id"],
                            "symptom_name": sym["name"],
                            "sym_aliases": sym_aliases,
                            "causes": sym.get("causes", []),
                            "safety": exp.get("safety", []),
                            "source": exp.get("source", ""),
                        }
                    )
        return items

    def experiment(self, exp_id: str) -> dict[str, Any] | None:
        return self.by_id.get(exp_id)

    def summary(self) -> dict[str, Any]:
        symptom_count = sum(len(s.get("symptoms", [])) for e in self.experiments for s in e.get("steps", []))
        cause_count = sum(
            len(c.get("causes", []))
            for e in self.experiments
            for s in e.get("steps", [])
            for c in s.get("symptoms", [])
        )
        return {
            "version": self.data.get("meta", {}).get("version", ""),
            "updated": self.data.get("meta", {}).get("updated", ""),
            "review_status": self.data.get("meta", {}).get("review_status", ""),
            "experiments": len(self.experiments),
            "symptoms": symptom_count,
            "causes": cause_count,
            "categories": sorted({e.get("category", "") for e in self.experiments if e.get("category")}),
        }

    def public_experiments(self, operations: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
        operations = operations or []
        by_exp: dict[str, dict[str, list[dict[str, Any]]]] = {}
        for op in operations:
            by_exp.setdefault(op["experiment_id"], {"standard": [], "error": []})[op["kind"]].append(op)
        result: list[dict[str, Any]] = []
        for exp in self.experiments:
            public = {
                "id": exp["id"],
                "name": exp["name"],
                "aliases": exp.get("aliases", []),
                "category": exp.get("category", ""),
                "intro": exp.get("intro", ""),
                "principle": exp.get("principle", ""),
                "safety_level": exp.get("safety_level", ""),
                "safety": exp.get("safety", []),
                "source": exp.get("source", ""),
                "steps": [
                    {
                        "id": step["id"],
                        "name": step["name"],
                        "points": step.get("points", []),
                        "expected": step.get("expected", ""),
                        "symptoms": [
                            {
                                "id": sym["id"],
                                "name": sym["name"],
                                "aliases": sym.get("aliases", []),
                                "cause_count": len(sym.get("causes", [])),
                            }
                            for sym in step.get("symptoms", [])
                        ],
                    }
                    for step in exp.get("steps", [])
                ],
            }
            groups = by_exp.get(exp["id"], {"standard": [], "error": []})
            public["operations"] = {
                "standard": groups["standard"],
                "error": groups["error"],
            }
            result.append(public)
        return result

    def score(self, query: str, item: dict[str, Any]) -> float:
        q = normalize(query)
        if not q:
            return 0.0
        score = 0.0
        for alias in item["exp_aliases"]:
            if alias and alias in q:
                score += 2.4 + min(len(alias), 6) * 0.22
        for alias in item["step_aliases"]:
            if alias and alias in q:
                score += 3.0 + min(len(alias), 6) * 0.3
        for alias in item["sym_aliases"]:
            if alias and alias in q:
                score += 5.2 + min(len(alias), 10) * 0.45
        sym_norm = normalize(item["symptom_name"])
        if q == sym_norm:
            score += 8.0
        ratio = SequenceMatcher(None, q, sym_norm).ratio()
        score += ratio * 4.0
        overlap = len(set(q) & set(sym_norm))
        score += min(overlap, 10) * 0.22
        return score

    def search(
        self, query: str, *, experiment_id: str | None = None, limit: int = 3
    ) -> list[dict[str, Any]]:
        candidates = self.items
        if experiment_id and experiment_id in self.by_id:
            candidates = [item for item in self.items if item["exp_id"] == experiment_id]
        scored = []
        for item in candidates:
            s = self.score(query, item)
            if s > 0:
                scored.append((s, item))
        scored.sort(key=lambda pair: pair[0], reverse=True)
        results = []
        for s, item in scored[:limit]:
            if s < MIN_MATCH_SCORE:
                continue
            result = dict(item)
            result["score"] = round(s, 2)
            results.append(result)
        return results

    def get_item(self, code: str) -> dict[str, Any] | None:
        return next((item for item in self.items if item["code"] == code), None)

    def search_documents(
        self,
        query: str,
        documents: list[dict[str, Any]],
        *,
        experiment_id: str | None = None,
        limit: int = 3,
    ) -> list[dict[str, Any]]:
        """在管理员上传并发布的文档块中做轻量关键词检索。"""
        q = normalize(query)
        if not q or not documents:
            return []
        qgrams = bigrams(q)
        scored: list[tuple[float, dict[str, Any]]] = []
        for doc in documents:
            if (
                experiment_id
                and doc.get("experiment_id")
                and doc["experiment_id"] != experiment_id
            ):
                continue
            text = normalize(f"{doc.get('title', '')} {doc.get('text', '')}")
            if not text:
                continue
            score = 0.0
            if q in text:
                score += 8.0
            if q in normalize(doc.get("title", "")):
                score += 4.0
            tgrams = bigrams(text)
            if qgrams:
                score += 10.0 * len(qgrams & tgrams) / len(qgrams)
            score += SequenceMatcher(None, q, normalize(doc.get("title", ""))).ratio() * 2.0
            if score >= 1.6:
                hit = dict(doc)
                hit["score"] = round(score, 2)
                scored.append((score, hit))
        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [item for _, item in scored[:limit]]


class ChemEngine:
    name = "chem"

    def __init__(self) -> None:
        self.backend = "none"
        self.provider = "本地知识库"
        self.api_base = ""
        self.api_key = ""
        self.model = ""
        self.agent_name = os.environ.get("CHEM_AGENT_NAME", "chem")
        self.agent_model = ""
        self.agent_id = ""
        self.instructions = "一名大学生的化学学习助手。"
        self.cherry_data = Path(
            os.environ.get(
                "CHERRY_DATA_DIR",
                str(Path(os.environ.get("APPDATA", Path.home())) / "CherryStudio" / "Data"),
            )
        )
        self.trust_env = False
        self.configured = False
        self.last_error = ""
        self.last_checked = ""
        self.refresh()

    # -- 配置 ---------------------------------------------------------------
    def refresh(self) -> None:
        requested = os.environ.get("CHEM_BACKEND", "").strip().lower()
        direct_key = os.environ.get("CHEM_API_KEY", "").strip()

        if requested in {"direct", "api", "deepseek", "openai"}:
            self._configure_direct()
        elif requested in {"cherry", "cherry-studio", "cherry_studio"}:
            self._configure_cherry()
        elif direct_key:
            # 显式给了直连 Key，就优先直连，不去依赖 Cherry。
            self._configure_direct()
        else:
            self._configure_cherry()
            if not self.configured:
                self.backend = "none"
                self.provider = "本地知识库"
                self.api_base = ""
                self.model = ""
                if not self.last_error:
                    self.last_error = "未配置 chem 模型 API Key"

        self.last_checked = time.strftime("%Y-%m-%d %H:%M:%S")

    def _configure_direct(self) -> None:
        self.backend = "direct"
        self.provider = (
            os.environ.get("CHEM_PROVIDER_NAME", "DeepSeek API").strip() or "DeepSeek API"
        )
        self.api_base = os.environ.get(
            "CHEM_API_BASE", "https://api.deepseek.com"
        ).rstrip("/")
        self.api_key = os.environ.get("CHEM_API_KEY", "").strip()
        self.model = os.environ.get("CHEM_MODEL", "deepseek-flash").strip()
        self.agent_model = self.model
        self.agent_id = ""
        self.instructions = (
            os.environ.get(
                "CHEM_INSTRUCTIONS", "一名大学生的化学学习助手。"
            ).strip()
            or "一名大学生的化学学习助手。"
        )
        self.trust_env = os.environ.get("CHEM_TRUST_ENV", "0").lower() in {
            "1",
            "true",
            "yes",
        }
        self.configured = bool(self.api_key)
        self.last_error = "" if self.configured else "未配置 CHEM_API_KEY"

    def _configure_cherry(self) -> None:
        self.backend = "cherry"
        self.provider = "Cherry Studio"
        self.api_base = os.environ.get(
            "CHERRY_API_BASE", "http://127.0.0.1:23333"
        ).rstrip("/")
        self.agent_name = os.environ.get("CHEM_AGENT_NAME", "chem")
        self.api_key = os.environ.get("CHERRY_API_KEY", "").strip() or self._read_api_key()
        self.model = "deepseek:deepseek-flash"
        self.agent_model = ""
        self.agent_id = ""
        self.instructions = "一名大学生的化学学习助手。"
        self.trust_env = False
        meta = self._read_agent()
        if meta:
            self.agent_id = meta.get("id", "")
            self.agent_model = meta.get("model", "") or ""
            self.instructions = meta.get("instructions", "") or self.instructions
            if self.agent_model:
                # Cherry API 网关把 provider::model 显示为 provider:model
                self.model = self.agent_model.replace("::", ":", 1)
        self.configured = bool(self.api_key)
        self.last_error = "" if self.configured else "未找到 Cherry Studio API 密钥"

    def _read_api_key(self) -> str:
        db_path = self.cherry_data / "cherrystudio.sqlite"
        if not db_path.exists():
            return ""
        try:
            con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=3)
            con.row_factory = sqlite3.Row
            row = con.execute(
                "SELECT value FROM preference WHERE scope = 'default' "
                "AND key = 'feature.api_gateway.api_key' LIMIT 1"
            ).fetchone()
            con.close()
            if row and row["value"]:
                try:
                    return json.loads(row["value"])
                except json.JSONDecodeError:
                    return str(row["value"]).strip().strip('"')
        except sqlite3.Error:
            pass
        return ""

    def _read_agent(self) -> dict[str, Any] | None:
        db_path = self.cherry_data / "cherrystudio.sqlite"
        if not db_path.exists():
            return None
        try:
            con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=3)
            con.row_factory = sqlite3.Row
            row = con.execute(
                "SELECT id, name, instructions, model FROM agent "
                "WHERE name = ? AND deleted_at IS NULL LIMIT 1",
                (self.agent_name,),
            ).fetchone()
            con.close()
            return dict(row) if row else None
        except sqlite3.Error:
            return None

    def status(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "backend": self.backend,
            "provider": self.provider,
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "configured": self.configured,
            "model": self.model,
            "agent_model": self.agent_model,
            "api_base": self.api_base,
            "instructions_loaded": bool(self.instructions),
            "last_error": self.last_error,
            "last_checked": self.last_checked,
            "trust_env": self.trust_env,
            "mode": self.provider if self.configured else "本地知识库",
        }

    # -- HTTP ---------------------------------------------------------------
    def _session(self) -> requests.Session:
        session = requests.Session()
        # Cherry 的本地网关必须直连；直连云端 API 时可用 CHEM_TRUST_ENV 决定是否走系统代理。
        session.trust_env = self.trust_env
        return session

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
        }

    def _models_url(self) -> str:
        if self.api_base.endswith("/v1"):
            return f"{self.api_base}/models"
        return f"{self.api_base}/v1/models"

    def _chat_url(self) -> str:
        if self.api_base.endswith("/chat/completions"):
            return self.api_base
        if self.api_base.endswith("/v1"):
            return f"{self.api_base}/chat/completions"
        return f"{self.api_base}/v1/chat/completions"

    def ping(self) -> dict[str, Any]:
        started = time.perf_counter()
        if not self.configured:
            return {
                "ok": False,
                "message": self.last_error or "chem 引擎尚未配置",
                "elapsed_ms": 0,
            }
        try:
            response = self._session().get(
                self._models_url(),
                headers=self._headers(),
                timeout=(4, 15),
            )
            response.raise_for_status()
            models = [m.get("id", "") for m in response.json().get("data", [])]
            if self.model not in models:
                return {
                    "ok": False,
                    "message": f"API 在线，但没有找到模型 {self.model}",
                    "models": models,
                    "elapsed_ms": round((time.perf_counter() - started) * 1000),
                }
            self.last_error = ""
            return {
                "ok": True,
                "message": f"{self.provider} 可用",
                "models": models,
                "elapsed_ms": round((time.perf_counter() - started) * 1000),
            }
        except requests.RequestException as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            message = (
                "连不上 Cherry Studio 本地 API，请确认 Cherry Studio 正在运行且 API 网关已开启"
                if self.backend == "cherry"
                else "连不上模型 API，请检查 CHEM_API_BASE、服务器出网和代理设置"
            )
            return {
                "ok": False,
                "message": message,
                "detail": self.last_error,
                "elapsed_ms": round((time.perf_counter() - started) * 1000),
            }

    def smoke_test(self) -> dict[str, Any]:
        ping = self.ping()
        if not ping.get("ok"):
            return ping
        started = time.perf_counter()
        try:
            content = self._chat(
                system="你是化学实验助教。只回答一句，不要客套。",
                user="滴定终点颜色一闪就没了，最可能是什么操作问题？",
                max_tokens=600,
                json_mode=False,
            )
            return {
                "ok": True,
                "message": "模型调用正常",
                "sample": clip(content, 300),
                "elapsed_ms": round((time.perf_counter() - started) * 1000),
            }
        except Exception as exc:  # noqa: BLE001 - 需要把可读错误返回给管理员
            self.last_error = f"{type(exc).__name__}: {exc}"
            return {
                "ok": False,
                "message": "模型服务在线，但模型调用失败",
                "detail": clip(str(exc), 500),
                "elapsed_ms": round((time.perf_counter() - started) * 1000),
            }

    def _chat(
        self, *, system: str, user: str, max_tokens: int = 4000, json_mode: bool = True
    ) -> str:
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": 0.15,
            "max_tokens": max_tokens,
            "stream": False,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        response = self._session().post(
            self._chat_url(),
            headers=self._headers(),
            json=payload,
            timeout=(6, 65),
        )
        if response.status_code == 400 and "response_format" in response.text:
            payload.pop("response_format", None)
            response = self._session().post(
                self._chat_url(),
                headers=self._headers(),
                json=payload,
                timeout=(6, 65),
            )
        response.raise_for_status()
        data = response.json()
        try:
            choice = data["choices"][0]
            content = choice["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ValueError("模型返回格式异常") from exc
        if not content:
            raise ValueError("模型返回了空内容")
        if choice.get("finish_reason") == "length":
            raise ValueError("模型输出被长度限制截断")
        return content

    # -- 生成排查建议 -------------------------------------------------------
    def diagnose(
        self,
        *,
        query: str,
        experiment_id: str | None,
        kb: KnowledgeBase,
        operations: list[dict[str, Any]],
        documents: list[dict[str, Any]] | None = None,
        vision: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        matches = kb.search(query, experiment_id=experiment_id, limit=3)
        doc_hits = kb.search_documents(
            query,
            documents or [],
            experiment_id=experiment_id,
            limit=3,
        )
        selected_exp = kb.experiment(experiment_id) if experiment_id else None

        if not matches and not doc_hits:
            result = self._no_coverage(query, selected_exp, kb)
        elif not self.configured:
            if matches:
                result = self._local_answer(query, matches, selected_exp, kb)
            else:
                result = self._local_doc_answer(query, doc_hits, selected_exp)
            result["warning"] = (
                "chem 引擎未配置，当前为本地知识库结果。"
                if matches
                else "chem 引擎未配置，只能列出上传资料的相关段落。"
            )
        else:
            system_prompt = self._system_prompt()
            user_prompt = self._user_prompt(
                query, matches, selected_exp, kb, operations, doc_hits, vision
            )
            try:
                try:
                    raw = self._chat(system=system_prompt, user=user_prompt, max_tokens=4000)
                    parsed = self._parse_json(raw)
                except Exception:
                    # 推理模型偶尔会用完输出预算或返回空内容，再给一次更宽的预算。
                    raw = self._chat(
                        system=system_prompt
                        + "\n上一次输出没有完整结束。这次请直接给出完整 JSON，不要省略字段。",
                        user=user_prompt,
                        max_tokens=5000,
                    )
                    parsed = self._parse_json(raw)
                result = self._normalize_online(
                    parsed, matches, selected_exp, kb, doc_hits
                )
                result["engine_mode"] = self.backend
                result["warning"] = ""
                self.last_error = ""
            except Exception as exc:  # noqa: BLE001 - 模型失败时必须有可用的本地兜底
                self.last_error = f"{type(exc).__name__}: {exc}"
                if matches:
                    result = self._local_answer(query, matches, selected_exp, kb)
                    result["warning"] = "chem 引擎暂时不可用，已用本地知识库给出排查建议。"
                else:
                    result = self._local_doc_answer(query, doc_hits, selected_exp)
                    result["warning"] = "chem 引擎暂时不可用，只能列出上传资料的相关段落。"
                result["engine_mode"] = "local"

        result["engine_name"] = self.name
        result["provider"] = self.provider
        result["model"] = self.model
        result["duration_ms"] = round((time.perf_counter() - started) * 1000)
        result["matched"] = self._matched_payload(matches)
        result["document_matches"] = self._document_payload(doc_hits)
        if vision:
            result["vision"] = vision
        return result

    def _system_prompt(self) -> str:
        return f"""你是 chem，一名基础化学实验助教。你的任务不是聊天，而是帮学生把眼前的现象排查清楚。

智能体原始设定：{self.instructions}

必须遵守：
1. 具体原因、验证方法和处理动作只能依据【知识库条目】【管理员操作数据】和【管理员上传的参考资料】。资料没有写的数字、浓度、体积、温度阈值不得编造；需要数值时写“按讲义要求”。
2. 安全优先。出现灼伤、起火、泄漏、强氧化剂混放、密闭加热等风险时，safety 必须给出停止操作并报告老师的建议。
3. 用学生能直接执行的动作说话，例如“看尖嘴是否充满液体”“取上清液滴加检验试剂”，不要写空泛的“注意规范操作”。
4. 不使用“作为 AI”“希望对你有帮助”“首先/其次/最后”这类套话，也不复述学生的问题。
5. 原因最多 3 条，按可能性从高到低排列；资料不足时 confidence 用“低”，并在 next_info 说明还需要补充什么。
6. 若检索条目与问题明显无关，covered 设为 false，causes 留空，不要硬猜。
7. 输出纯 JSON，不要 Markdown，不要代码围栏。结构必须是：
{{
  "covered": true,
  "summary": "一到两句话，说明最像哪类问题以及现在先做什么",
  "confidence": "高|中|低",
  "causes": [
    {{
      "text": "可能原因",
      "likelihood": "高|中|低",
      "why": "一句话说明为什么会出现这个现象",
      "verify": "一个具体、可观察的验证动作",
      "action": "确认后怎么处理"
    }}
  ],
  "safety": ["安全提醒，按严重程度排序"],
  "sources": ["使用的知识条目编号或操作数据标题"],
  "next_info": ["还需要学生补充的信息，最多两条"]
}}"""

    def _user_prompt(
        self,
        query: str,
        matches: list[dict[str, Any]],
        selected_exp: dict[str, Any] | None,
        kb: KnowledgeBase,
        operations: list[dict[str, Any]],
        documents: list[dict[str, Any]] | None = None,
        vision: dict[str, Any] | None = None,
    ) -> str:
        context = []
        for item in matches[:3]:
            causes = []
            for cause in item["causes"][:4]:
                causes.append(
                    {
                        "原因": clip(cause.get("text"), 160),
                        "可能性": cause.get("likelihood", ""),
                        "机理": clip(cause.get("mechanism"), 240),
                        "验证": clip(cause.get("verify"), 240),
                        "处理": clip(cause.get("remedy"), 240),
                        "安全": clip(cause.get("safety"), 180),
                    }
                )
            context.append(
                {
                    "编号": item["code"],
                    "实验": item["exp_name"],
                    "步骤": item["step_name"],
                    "现象": item["symptom_name"],
                    "来源": clip(item.get("source"), 160),
                    "原因": causes,
                }
            )

        ops_context = []
        for op in operations[:12]:
            ops_context.append(
                {
                    "类型": "标准操作" if op["kind"] == "standard" else "误差操作",
                    "实验": op["experiment_name"],
                    "步骤": op.get("step", ""),
                    "标题": clip(op.get("title"), 120),
                    "条件": clip(op.get("conditions"), 220),
                    "预期": clip(op.get("expected"), 220),
                    "实际": clip(op.get("observed"), 220),
                    "偏差": clip(op.get("deviation"), 220),
                    "原因": clip(op.get("cause"), 220),
                }
            )

        selected = None
        if selected_exp:
            selected = {
                "实验": selected_exp["name"],
                "实验编号": selected_exp["id"],
                "安全提示": selected_exp.get("safety", []),
                "标准操作摘要": [
                    {"步骤": step["name"], "要点": step.get("points", []), "预期": step.get("expected", "")}
                    for step in selected_exp.get("steps", [])
                ],
            }

        doc_context = []
        for doc in (documents or [])[:3]:
            doc_context.append(
                {
                    "标题": clip(doc.get("title"), 180),
                    "实验": clip(doc.get("experiment_name"), 100),
                    "步骤": clip(doc.get("step"), 100),
                    "来源": clip(doc.get("source"), 180),
                    "内容": clip(doc.get("text"), 1200),
                }
            )

        payload = {
            "学生问题": query,
            "学生选择的实验": selected,
            "照片观察（视觉模型描述，未核实）": vision or None,
            "检索到的知识条目": context,
            "管理员维护的操作数据": ops_context,
            "管理员上传的参考资料": doc_context,
        }
        return (
            "下面是本次排查可用的事实材料。只根据这些材料回答，不要补造没有的数值。"
            "照片观察只是可见现象，不能当作完整操作记录。\n\n"
            + json.dumps(payload, ensure_ascii=False, indent=1)
        )

    @staticmethod
    def _parse_json(raw: str) -> dict[str, Any]:
        text = raw.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)
        start = text.find("{")
        if start < 0:
            raise ValueError("模型没有返回 JSON 对象")
        try:
            value, _ = json.JSONDecoder().raw_decode(text[start:])
        except json.JSONDecodeError as exc:
            raise ValueError(f"模型 JSON 解析失败: {exc.msg}") from exc
        if not isinstance(value, dict):
            raise ValueError("模型返回的不是 JSON 对象")
        return value

    def _normalize_online(
        self,
        parsed: dict[str, Any],
        matches: list[dict[str, Any]],
        selected_exp: dict[str, Any] | None,
        kb: KnowledgeBase,
        documents: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        causes = []
        for raw in parsed.get("causes", [])[:3]:
            if isinstance(raw, str):
                raw = {"text": raw}
            if not isinstance(raw, dict) or not clip(raw.get("text"), 300):
                continue
            likelihood = raw.get("likelihood", "中")
            if likelihood not in VALID_LIKELIHOOD:
                likelihood = "中"
            causes.append(
                {
                    "text": clip(raw.get("text"), 300),
                    "likelihood": likelihood,
                    "why": clip(raw.get("why"), 500),
                    "verify": clip(raw.get("verify"), 500),
                    "action": clip(raw.get("action"), 500),
                }
            )

        confidence = parsed.get("confidence", "低")
        if confidence not in VALID_CONFIDENCE:
            confidence = "低"

        sources = as_list(parsed.get("sources"), limit=6)
        if not sources:
            sources = [item["code"] for item in matches[:3]]
            sources.extend(item.get("title", "") for item in (documents or [])[:3])
            sources = [source for source in sources if source]

        safety = as_list(parsed.get("safety"), limit=4)
        if not safety and selected_exp:
            safety = as_list(selected_exp.get("safety"), limit=3)

        summary = clip(parsed.get("summary"), 600)
        if not summary:
            if matches:
                match = matches[0]
                summary = f"更接近「{match['exp_name']} · {match['step_name']}」中的「{match['symptom_name']}」。先按顺序验证，别急着重做。"
            elif documents:
                summary = f"找到上传资料《{clip(documents[0].get('title'), 100)}》，先核对资料内容，再按讲义要求验证。"
            else:
                summary = "现有资料不足，请补充实验名称和具体现象。"

        covered = parsed.get("covered", True)
        if not isinstance(covered, bool):
            covered = str(covered).lower() not in {"false", "0", "否"}
        if not causes and covered:
            # 模型没给原因时，不把空结果伪装成正常判断。
            covered = False

        return {
            "covered": covered,
            "summary": summary,
            "confidence": confidence if covered else "低",
            "causes": causes if covered else [],
            "safety": safety,
            "sources": sources,
            "next_info": as_list(parsed.get("next_info"), limit=3),
            "engine_name": self.name,
            "engine_mode": self.backend,
            "model": self.model,
            "warning": "",
        }

    def _local_answer(
        self,
        query: str,
        matches: list[dict[str, Any]],
        selected_exp: dict[str, Any] | None,
        kb: KnowledgeBase,
    ) -> dict[str, Any]:
        if not matches:
            return self._no_coverage(query, selected_exp, kb)

        causes = []
        safety: list[str] = []
        sources: list[str] = []
        for item in matches[:2]:
            if item["code"] not in sources:
                sources.append(item["code"])
            for cause in item["causes"]:
                text = clip(cause.get("text"), 300)
                if not text or any(c["text"] == text for c in causes):
                    continue
                causes.append(
                    {
                        "text": text,
                        "likelihood": cause.get("likelihood", "中")
                        if cause.get("likelihood") in VALID_LIKELIHOOD
                        else "中",
                        "why": clip(cause.get("mechanism"), 500),
                        "verify": clip(cause.get("verify"), 500),
                        "action": clip(cause.get("remedy"), 500),
                    }
                )
                for key in ("safety",):
                    if cause.get(key):
                        safety.append(clip(cause[key], 300))
                if len(causes) >= 3:
                    break
            if len(causes) >= 3:
                break

        for content in (selected_exp or {}).get("safety", []):
            if len(safety) >= 3:
                break
            if content not in safety:
                safety.append(content)
        for item in matches:
            for content in item.get("safety", []):
                if len(safety) >= 3:
                    break
                if content not in safety:
                    safety.append(content)
        safety = safety[:3]

        top = matches[0]
        summary = (
            f"你描述的情况与「{top['exp_name']} · {top['step_name']}」里的"
            f"「{top['symptom_name']}」最接近。先验证排在前面的原因，不必一次全部重做。"
        )
        confidence = "中" if top["score"] >= 8 else "低"
        return {
            "covered": True,
            "summary": summary,
            "confidence": confidence,
            "causes": causes,
            "safety": safety,
            "sources": sources,
            "next_info": [
                "补充当时的操作步骤、用量和颜色/温度等变化，判断会更准确。",
                "如果现象持续或伴随发热、冒烟、泄漏，先停止操作并报告老师。",
            ],
            "engine_name": self.name,
            "engine_mode": "local",
            "model": self.model,
        }

    def _local_doc_answer(
        self,
        query: str,
        documents: list[dict[str, Any]],
        selected_exp: dict[str, Any] | None,
    ) -> dict[str, Any]:
        titles = []
        for doc in documents[:3]:
            title = clip(doc.get("title"), 180)
            if title and title not in titles:
                titles.append(title)
        safety = as_list((selected_exp or {}).get("safety"), limit=3)
        return {
            "covered": False,
            "summary": "找到与问题相关的上传资料，但 chem 模型当前不可用，暂时不能生成原因判断。请先核对下面的资料，再请助教确认。",
            "confidence": "低",
            "causes": [],
            "safety": safety,
            "sources": titles,
            "next_info": [
                "打开管理员上传的参考资料，按资料中的操作条件和预期结果逐项核对。",
                "如果现象持续或伴随发热、冒烟、泄漏，先停止操作并报告老师。",
            ],
            "engine_name": self.name,
            "engine_mode": "local",
            "model": self.model,
        }

    def _no_coverage(
        self,
        query: str,
        selected_exp: dict[str, Any] | None,
        kb: KnowledgeBase,
    ) -> dict[str, Any]:
        safety = as_list((selected_exp or {}).get("safety"), limit=2)
        return {
            "covered": False,
            "summary": "现有资料还没有覆盖这个现象。先补清楚实验名称、所在步骤和当时的操作，再做判断。",
            "confidence": "低",
            "causes": [],
            "safety": safety,
            "sources": [],
            "next_info": [
                "补充实验名称、具体步骤、试剂浓度或用量，以及你看到的颜色、沉淀、温度或读数变化。",
                "也可以到「实验」页查看该实验的标准操作，或直接请助教现场确认。",
            ],
            "engine_name": self.name,
            "engine_mode": "local",
            "model": self.model,
            "warning": "",
            "matched": [],
        }

    def _matched_payload(self, matches: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return [
            {
                "code": match["code"],
                "experiment_id": match["exp_id"],
                "experiment": match["exp_name"],
                "step": match["step_name"],
                "symptom": match["symptom_name"],
                "score": match["score"],
            }
            for match in matches
        ]

    def _document_payload(self, documents: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return [
            {
                "document_id": doc.get("document_id"),
                "title": clip(doc.get("title"), 180),
                "experiment_id": doc.get("experiment_id", ""),
                "experiment": clip(doc.get("experiment_name"), 100),
                "step": clip(doc.get("step"), 100),
                "source": clip(doc.get("source"), 180),
                "score": doc.get("score", 0),
            }
            for doc in documents
        ]


def load_kb() -> KnowledgeBase:
    return KnowledgeBase(KB_PATH)
