# -*- coding: utf-8 -*-
"""基础化学实验故障排查 · 移动端 H5 服务端。

生产推荐：复制 server.env.example 为 server.env，填写模型 API Key；
启动：uv run python app.py
"""

from __future__ import annotations

import base64
import binascii
import hmac
import os
import re
import socket
import sqlite3
import threading
import time
import webbrowser
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path
from threading import Lock
from typing import Any, Literal

import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

import database as db
from engine import ChemEngine, KnowledgeBase, load_kb
from vision import VisionEngine, VisionError

BASE = Path(__file__).resolve().parent


def _load_env_file(path: Path) -> None:
    """加载项目内的 server.env；不覆盖系统环境中已存在的变量。"""
    if not path.exists():
        return
    try:
        for raw in path.read_text(encoding="utf-8-sig").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[7:].strip()
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                value = value[1:-1]
            if key and key not in os.environ:
                os.environ[key] = value
    except OSError as exc:
        print(f"[env] 读取 server.env 失败：{exc}")


_load_env_file(BASE / "server.env")
KB: KnowledgeBase = load_kb()
ENGINE: ChemEngine = ChemEngine()
VISION: VisionEngine = VisionEngine()
STARTED_AT = time.time()
PORT = int(os.environ.get("LAB_PORT", "8501"))
HOST = os.environ.get("LAB_HOST", "0.0.0.0")
SESSION_SECURE = os.environ.get("LAB_SESSION_SECURE", "0").lower() in {"1", "true", "yes"}

login_attempts: dict[str, deque[float]] = {}
diagnose_attempts: dict[int, deque[float]] = {}
rate_lock = Lock()

QUICK_PROMPTS = [
    {"label": "终点颜色一闪就没了", "experiment_id": "acid-base-titration"},
    {"label": "平行样结果对不上", "experiment_id": "acid-base-titration"},
    {"label": "高锰酸钾出现棕色浑浊", "experiment_id": "permanganate-titration"},
    {"label": "EDTA 终点调不到纯蓝", "experiment_id": "edta-titration"},
    {"label": "砖红色终点反复消失", "experiment_id": "mohr-method"},
    {"label": "吸光度一直跳", "experiment_id": "iron-phenanthroline"},
]


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init_db(KB.data)
    print(f"[app] 知识库：{KB.summary()}")
    print(f"[app] chem 引擎：{ENGINE.status()['mode']} / {ENGINE.model}")
    print(f"[app] 视觉引擎：{VISION.status()['mode']} / {VISION.model}")
    yield


app = FastAPI(
    title="化学实验故障排查",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
    lifespan=lifespan,
)
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE / "templates"))


# ---------------------------------------------------------------------------
# 基础中间件与异常处理
# ---------------------------------------------------------------------------


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; style-src 'self'; "
        "img-src 'self' data:; connect-src 'self'; font-src 'self'; "
        "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
    )
    if request.url.path.startswith("/api/") or request.url.path in {"/", "/login"}:
        response.headers["Cache-Control"] = "no-store"
    elif request.url.path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-cache"
    return response


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    if request.url.path.startswith("/api/"):
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": exc.detail, "status": exc.status_code},
            headers=exc.headers,
        )
    if exc.status_code == 401:
        return RedirectResponse("/login", status_code=303)
    return HTMLResponse("<h1>请求无法完成</h1><p>" + str(exc.detail) + "</p>", status_code=exc.status_code)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    if request.url.path.startswith("/api/"):
        return JSONResponse(
            status_code=422,
            content={"error": "提交的数据不完整或格式不正确", "status": 422},
        )
    return HTMLResponse("<h1>提交的数据不完整</h1>", status_code=422)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    print(f"[error] {request.method} {request.url.path}: {type(exc).__name__}: {exc}")
    if request.url.path.startswith("/api/"):
        return JSONResponse(
            status_code=500,
            content={"error": "服务器处理失败，请稍后重试", "status": 500},
        )
    return HTMLResponse("<h1>服务器处理失败</h1><p>请回到上一页重试。</p>", status_code=500)


# ---------------------------------------------------------------------------
# 认证依赖
# ---------------------------------------------------------------------------


def _session_user(request: Request) -> dict[str, Any]:
    raw_token = request.cookies.get(db.SESSION_COOKIE)
    user = db.resolve_session(raw_token)
    if not user:
        raise HTTPException(status_code=401, detail="登录已过期，请重新登录")
    user["_raw_token"] = raw_token
    return user


def require_user(request: Request) -> dict[str, Any]:
    return _session_user(request)


def require_admin(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="需要开发者权限")
    return user


def _verify_csrf(request: Request, user: dict[str, Any]) -> None:
    token = request.headers.get("X-CSRF-Token", "")
    expected = user.get("csrf_token", "")
    if not token or not expected or not hmac.compare_digest(token, expected):
        raise HTTPException(status_code=403, detail="页面会话已更新，请刷新后重试")


def require_csrf(request: Request, user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    _verify_csrf(request, user)
    return user


def require_admin_csrf(
    request: Request, user: dict[str, Any] = Depends(require_admin)
) -> dict[str, Any]:
    _verify_csrf(request, user)
    return user


def public_user(user: dict[str, Any]) -> dict[str, Any]:
    fields = (
        "id",
        "username",
        "display_name",
        "role",
        "student_no",
        "class_name",
        "is_active",
        "must_change_password",
        "created_at",
        "last_login_at",
    )
    return {key: user.get(key) for key in fields}


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _login_allowed(ip: str) -> bool:
    now = time.monotonic()
    with rate_lock:
        attempts = login_attempts.setdefault(ip, deque())
        while attempts and now - attempts[0] > 600:
            attempts.popleft()
        return len(attempts) < 8


def _record_login_failure(ip: str) -> None:
    with rate_lock:
        login_attempts.setdefault(ip, deque()).append(time.monotonic())


def _clear_login_attempts(ip: str) -> None:
    with rate_lock:
        login_attempts.pop(ip, None)


def _diagnose_allowed(user_id: int) -> bool:
    now = time.monotonic()
    with rate_lock:
        attempts = diagnose_attempts.setdefault(user_id, deque())
        while attempts and now - attempts[0] > 600:
            attempts.popleft()
        if len(attempts) >= 30:
            return False
        attempts.append(now)
        return True


# ---------------------------------------------------------------------------
# 请求模型
# ---------------------------------------------------------------------------


class LoginBody(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=200)
    role: Literal["student", "admin"]


class DiagnoseBody(BaseModel):
    query: str = Field(default="", max_length=1000)
    experiment_id: str = Field(default="", max_length=80)
    image_data: str = Field(default="", max_length=4_000_000)
    image_mime: str = Field(default="", max_length=40)


class FeedbackBody(BaseModel):
    helpful: bool
    note: str = Field(default="", max_length=500)


class ProfileBody(BaseModel):
    display_name: str = Field(min_length=1, max_length=40)
    student_no: str = Field(default="", max_length=40)
    class_name: str = Field(default="", max_length=80)


class PasswordBody(BaseModel):
    current_password: str = Field(min_length=1, max_length=200)
    new_password: str = Field(min_length=8, max_length=200)


class UserCreateBody(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=8, max_length=200)
    display_name: str = Field(min_length=1, max_length=40)
    role: Literal["student", "admin"] = "student"
    student_no: str = Field(default="", max_length=40)
    class_name: str = Field(default="", max_length=80)


class UserPatchBody(BaseModel):
    display_name: str | None = Field(default=None, max_length=40)
    student_no: str | None = Field(default=None, max_length=40)
    class_name: str | None = Field(default=None, max_length=80)
    is_active: bool | None = None
    new_password: str | None = Field(default=None, min_length=8, max_length=200)


class OperationBody(BaseModel):
    experiment_id: str = Field(min_length=1, max_length=80)
    step: str = Field(default="", max_length=120)
    kind: Literal["standard", "error"]
    title: str = Field(min_length=1, max_length=160)
    conditions: str = Field(default="", max_length=1000)
    expected: str = Field(default="", max_length=1000)
    observed: str = Field(default="", max_length=1000)
    deviation: str = Field(default="", max_length=1000)
    cause: str = Field(default="", max_length=1000)
    severity: Literal["", "低", "中", "高"] = ""
    source: str = Field(default="", max_length=300)


# ---------------------------------------------------------------------------
# 页面
# ---------------------------------------------------------------------------


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    if db.resolve_session(request.cookies.get(db.SESSION_COOKIE)):
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse(request, "login.html", {})


@app.get("/", response_class=HTMLResponse)
def app_page(request: Request):
    user = db.resolve_session(request.cookies.get(db.SESSION_COOKIE))
    if not user:
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse(request, "index.html", {"user": user})


@app.get("/health")
def health():
    return {
        "ok": True,
        "now": time.strftime("%Y-%m-%d %H:%M:%S"),
        "uptime_seconds": round(time.time() - STARTED_AT),
    }


# ---------------------------------------------------------------------------
# 登录与会话
# ---------------------------------------------------------------------------


@app.post("/api/login")
def login(body: LoginBody, request: Request):
    ip = _client_ip(request)
    if not _login_allowed(ip):
        raise HTTPException(status_code=429, detail="尝试次数过多，请 10 分钟后再试")
    user = db.authenticate(body.username, body.password, body.role)
    if not user:
        _record_login_failure(ip)
        raise HTTPException(status_code=401, detail="账号、密码或登录身份不匹配")
    _clear_login_attempts(ip)
    raw_token, _csrf, _expires = db.create_session(user["id"], request.headers.get("user-agent", ""))
    response = JSONResponse({"ok": True, "role": user["role"], "redirect": "/"})
    response.set_cookie(
        db.SESSION_COOKIE,
        raw_token,
        max_age=60 * 60 * 24 * db.SESSION_DAYS,
        httponly=True,
        samesite="lax",
        secure=SESSION_SECURE,
        path="/",
    )
    return response


@app.post("/api/logout")
def logout(
    request: Request,
    user: dict[str, Any] = Depends(require_csrf),
):
    db.delete_session(user.get("_raw_token"))
    response = JSONResponse({"ok": True})
    response.delete_cookie(db.SESSION_COOKIE, path="/")
    return response


# ---------------------------------------------------------------------------
# 应用数据
# ---------------------------------------------------------------------------


def _public_operation(op: dict[str, Any]) -> dict[str, Any]:
    keep = (
        "id",
        "experiment_id",
        "experiment_name",
        "step",
        "kind",
        "title",
        "conditions",
        "expected",
        "observed",
        "deviation",
        "cause",
        "severity",
        "source",
        "created_at",
        "updated_at",
    )
    return {key: op.get(key) for key in keep}


@app.get("/api/bootstrap")
def bootstrap(user: dict[str, Any] = Depends(require_user)):
    summary = KB.summary()
    engine_status = ENGINE.status()
    return {
        "user": public_user(user),
        "csrf": user["csrf_token"],
        "kb": summary,
        "engine": {
            "name": ENGINE.name,
            "backend": engine_status["backend"],
            "provider": engine_status["provider"],
            "model": ENGINE.model,
            "configured": ENGINE.configured,
            "mode": engine_status["mode"],
        },
        "vision": {
            "provider": VISION.provider,
            "model": VISION.model,
            "configured": VISION.configured,
        },
        "quick_prompts": QUICK_PROMPTS,
        "review_status": summary.get("review_status", ""),
    }


@app.get("/api/experiments")
def experiments(user: dict[str, Any] = Depends(require_user)):
    ops = db.list_operations(limit=1000)
    public_ops = [_public_operation(op) for op in ops]
    return {
        "experiments": KB.public_experiments(public_ops),
        "summary": KB.summary(),
    }


@app.post("/api/diagnose")
def diagnose(
    body: DiagnoseBody,
    user: dict[str, Any] = Depends(require_csrf),
):
    query = body.query.strip()
    image_data = body.image_data.strip()
    image_mime = body.image_mime.strip().lower()
    if not query and not image_data:
        raise HTTPException(status_code=400, detail="写一点现象，或上传一张实验照片")
    if not image_data and len(query) < 2:
        raise HTTPException(status_code=400, detail="至少写两个字，例如：颜色一闪就没了")
    if image_data and image_mime not in {"image/jpeg", "image/png", "image/webp"}:
        raise HTTPException(status_code=400, detail="图片只支持 JPG、PNG 或 WebP")
    if image_data:
        try:
            raw_image = base64.b64decode(image_data, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise HTTPException(status_code=400, detail="图片数据格式不正确") from exc
        if len(raw_image) > 2_800_000:
            raise HTTPException(status_code=400, detail="图片太大，请换一张小于 2.5 MB 的图片")
    if not _diagnose_allowed(user["id"]):
        raise HTTPException(status_code=429, detail="问诊次数较多，请稍后再试")

    experiment_id = body.experiment_id.strip()
    if experiment_id and KB.experiment(experiment_id) is None:
        raise HTTPException(status_code=400, detail="选择的实验不存在")

    started = time.perf_counter()
    vision: dict[str, Any] | None = None
    vision_warning = ""
    if image_data:
        if VISION.configured:
            try:
                vision = VISION.describe(image_data, image_mime, query)
            except VisionError as exc:
                vision_warning = f"照片识别失败：{exc}"
        else:
            vision_warning = "照片识别未配置 VISION_API_KEY"
        if not query and not vision:
            raise HTTPException(
                status_code=400,
                detail="照片识别不可用，请补充一句文字描述再提交",
            )

    vision_text = ""
    if vision:
        vision_text = " ".join(
            [
                str(vision.get("summary", "")),
                *[str(item) for item in vision.get("visible", [])],
                *[str(item) for item in vision.get("readings", [])],
                str(vision.get("search_text", "")),
            ]
        ).strip()
    effective_query = " ".join(part for part in (query, vision_text) if part).strip()
    display_query = query or "上传了一张实验照片"

    preliminary = KB.search(effective_query, experiment_id=experiment_id or None, limit=3)
    published_chunks = db.list_published_knowledge_chunks(limit=3000)
    doc_preview = KB.search_documents(
        effective_query,
        published_chunks,
        experiment_id=experiment_id or None,
        limit=3,
    )
    exp_ids: list[str] = []
    for match in preliminary:
        if match["exp_id"] not in exp_ids:
            exp_ids.append(match["exp_id"])
    for doc in doc_preview:
        if doc.get("experiment_id") and doc["experiment_id"] not in exp_ids:
            exp_ids.append(doc["experiment_id"])
    if experiment_id and experiment_id not in exp_ids:
        exp_ids.insert(0, experiment_id)
    ops_for_engine = db.get_operations_for_engine(exp_ids, per_kind=5)

    answer = ENGINE.diagnose(
        query=effective_query,
        experiment_id=experiment_id or None,
        kb=KB,
        operations=ops_for_engine,
        documents=published_chunks,
        vision=vision,
    )
    duration_ms = round((time.perf_counter() - started) * 1000)
    answer["duration_ms"] = duration_ms
    if vision_warning:
        answer["vision_warning"] = vision_warning
    if vision:
        answer["vision"] = vision
    matched = answer.get("matched") or []
    top = matched[0] if matched else {}
    doc_matches = answer.get("document_matches") or []
    doc_top = doc_matches[0] if doc_matches else {}
    selected_exp = KB.experiment(experiment_id) if experiment_id else None
    save_exp_id = (
        top.get("experiment_id")
        or doc_top.get("experiment_id")
        or (selected_exp or {}).get("id", "")
    )
    save_exp_name = (
        top.get("experiment")
        or doc_top.get("experiment")
        or (selected_exp or {}).get("name", "")
    )
    save_step = top.get("step") or doc_top.get("step") or ""
    diag_id = db.save_diagnosis(
        user_id=user["id"],
        query=display_query,
        experiment_id=save_exp_id,
        experiment_name=save_exp_name,
        step=save_step,
        symptom=top.get("symptom", ""),
        confidence=answer.get("confidence", "低"),
        engine_name=answer.get("engine_name", ENGINE.name),
        engine_mode=answer.get("engine_mode", "local"),
        model=answer.get("model", ENGINE.model),
        answer=answer,
        duration_ms=duration_ms,
    )
    return {
        "id": diag_id,
        "query": display_query,
        "answer": answer,
        "engine": {
            "name": answer.get("engine_name", ENGINE.name),
            "model": answer.get("model", ENGINE.model),
            "mode": answer.get("engine_mode", "local"),
        },
    }


@app.get("/api/diagnoses")
def diagnoses(
    limit: int = 50,
    user: dict[str, Any] = Depends(require_user),
):
    return {
        "items": db.list_diagnoses(user_id=user["id"], limit=limit, include_answer=False),
        "stats": db.user_diagnosis_stats(user["id"]),
    }


@app.get("/api/diagnoses/{diag_id}")
def diagnosis_detail(diag_id: int, user: dict[str, Any] = Depends(require_user)):
    item = db.get_diagnosis(diag_id, user_id=user["id"])
    if not item:
        raise HTTPException(status_code=404, detail="记录不存在")
    return item


@app.post("/api/diagnoses/{diag_id}/feedback")
def diagnosis_feedback(
    diag_id: int,
    body: FeedbackBody,
    user: dict[str, Any] = Depends(require_csrf),
):
    item = db.get_diagnosis(diag_id, user_id=user["id"])
    if not item:
        raise HTTPException(status_code=404, detail="记录不存在")
    db.set_feedback(diag_id, user["id"], body.helpful, body.note)
    return {"ok": True}


@app.put("/api/profile")
def update_profile(
    body: ProfileBody,
    user: dict[str, Any] = Depends(require_csrf),
):
    db.update_user_profile(
        user["id"],
        body.display_name.strip(),
        body.student_no.strip(),
        body.class_name.strip(),
    )
    return {"ok": True, "user": public_user(db.get_user(user["id"]) or {})}


@app.post("/api/profile/password")
def change_password(
    body: PasswordBody,
    user: dict[str, Any] = Depends(require_csrf),
):
    current_hash = db.get_user_password_hash(user["id"])
    if not current_hash or not db.verify_password(body.current_password, current_hash):
        raise HTTPException(status_code=400, detail="当前密码不正确")
    if body.current_password == body.new_password:
        raise HTTPException(status_code=400, detail="新密码不能与当前密码相同")
    db.set_user_password(user["id"], body.new_password, must_change_password=False)
    return {"ok": True}


@app.get("/api/operations")
def operations(
    experiment_id: str = "",
    kind: str = "",
    user: dict[str, Any] = Depends(require_user),
):
    rows = db.list_operations(
        experiment_id=experiment_id or None,
        kind=kind if kind in {"standard", "error"} else None,
        limit=500,
    )
    return {"items": [_public_operation(row) for row in rows]}


# ---------------------------------------------------------------------------
# 管理端
# ---------------------------------------------------------------------------


@app.get("/api/admin/overview")
def admin_overview(user: dict[str, Any] = Depends(require_admin)):
    stats = db.admin_overview_stats()
    stats.update(
        {
            "kb": KB.summary(),
            "engine": ENGINE.status(),
            "vision": VISION.status(),
            "uptime_seconds": round(time.time() - STARTED_AT),
        }
    )
    return {
        "stats": stats,
        "recent": db.list_diagnoses(limit=12, include_answer=False),
        "users_preview": db.list_users()[:5],
    }


@app.post("/api/admin/engine/test")
def admin_engine_test(user: dict[str, Any] = Depends(require_admin_csrf)):
    ENGINE.refresh()
    result = ENGINE.smoke_test()
    return {"result": result, "engine": ENGINE.status()}


@app.get("/api/admin/users")
def admin_users(user: dict[str, Any] = Depends(require_admin)):
    return {"items": db.list_users(), "counts": db.count_users()}


@app.post("/api/admin/users")
def admin_create_user(
    body: UserCreateBody,
    user: dict[str, Any] = Depends(require_admin_csrf),
):
    username = body.username.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username):
        raise HTTPException(status_code=400, detail="用户名只能用 3~32 位字母、数字、点、下划线或短横线")
    if body.password.strip() != body.password or len(body.password) < 8:
        raise HTTPException(status_code=400, detail="密码至少 8 位，且首尾不能有空格")
    try:
        user_id = db.create_user(
            username=username,
            password=body.password,
            display_name=body.display_name.strip(),
            role=body.role,
            student_no=body.student_no.strip(),
            class_name=body.class_name.strip(),
            must_change_password=True,
        )
    except sqlite3.IntegrityError as exc:
        raise HTTPException(status_code=409, detail="用户名已存在") from exc
    return {"ok": True, "user": db.get_user(user_id)}


@app.patch("/api/admin/users/{user_id}")
def admin_patch_user(
    user_id: int,
    body: UserPatchBody,
    admin: dict[str, Any] = Depends(require_admin_csrf),
):
    target = db.get_user(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="用户不存在")
    if user_id == admin["id"] and body.is_active is False:
        raise HTTPException(status_code=400, detail="不能停用当前登录的管理员账号")

    display_name = body.display_name.strip() if body.display_name is not None else target["display_name"]
    student_no = body.student_no.strip() if body.student_no is not None else target["student_no"]
    class_name = body.class_name.strip() if body.class_name is not None else target["class_name"]
    if not display_name:
        raise HTTPException(status_code=400, detail="显示名称不能为空")
    db.update_user_profile(user_id, display_name, student_no, class_name)

    if body.new_password is not None:
        if len(body.new_password) < 8:
            raise HTTPException(status_code=400, detail="新密码至少 8 位")
        db.set_user_password(user_id, body.new_password, must_change_password=True)
    if body.is_active is not None:
        db.set_user_active(user_id, body.is_active)
    return {"ok": True, "user": db.get_user(user_id)}


def _validated_operation(body: OperationBody, admin_id: int) -> dict[str, Any]:
    exp = KB.experiment(body.experiment_id)
    if not exp:
        raise HTTPException(status_code=400, detail="实验不存在")
    if body.kind == "standard" and not (body.conditions.strip() or body.expected.strip()):
        raise HTTPException(status_code=400, detail="标准操作至少填写操作条件或预期结果")
    if body.kind == "error" and not (
        body.observed.strip() or body.deviation.strip() or body.cause.strip()
    ):
        raise HTTPException(status_code=400, detail="误差操作至少填写实际现象、偏差影响或原因")
    return {
        "experiment_id": exp["id"],
        "experiment_name": exp["name"],
        "step": body.step.strip(),
        "kind": body.kind,
        "title": body.title.strip(),
        "conditions": body.conditions.strip(),
        "expected": body.expected.strip(),
        "observed": body.observed.strip(),
        "deviation": body.deviation.strip(),
        "cause": body.cause.strip(),
        "severity": body.severity,
        "source": body.source.strip() or "开发者录入",
    }


@app.get("/api/admin/operations")
def admin_operations(
    experiment_id: str = "",
    kind: str = "",
    user: dict[str, Any] = Depends(require_admin),
):
    rows = db.list_operations(
        experiment_id=experiment_id or None,
        kind=kind if kind in {"standard", "error"} else None,
        limit=1000,
    )
    return {"items": rows, "counts": db.count_operations()}


@app.post("/api/admin/operations")
def admin_create_operation(
    body: OperationBody,
    user: dict[str, Any] = Depends(require_admin_csrf),
):
    data = _validated_operation(body, user["id"])
    try:
        op_id = db.create_operation(data, user["id"])
    except sqlite3.IntegrityError as exc:
        raise HTTPException(
            status_code=409, detail="同一实验下已有同类型同标题的记录"
        ) from exc
    return {"ok": True, "item": db.get_operation(op_id)}


@app.put("/api/admin/operations/{op_id}")
def admin_update_operation(
    op_id: int,
    body: OperationBody,
    user: dict[str, Any] = Depends(require_admin_csrf),
):
    if not db.get_operation(op_id):
        raise HTTPException(status_code=404, detail="记录不存在")
    data = _validated_operation(body, user["id"])
    try:
        db.update_operation(op_id, data)
    except sqlite3.IntegrityError as exc:
        raise HTTPException(
            status_code=409, detail="同一实验下已有同类型同标题的记录"
        ) from exc
    return {"ok": True, "item": db.get_operation(op_id)}


@app.delete("/api/admin/operations/{op_id}")
def admin_delete_operation(
    op_id: int,
    user: dict[str, Any] = Depends(require_admin_csrf),
):
    if not db.get_operation(op_id):
        raise HTTPException(status_code=404, detail="记录不存在")
    db.delete_operation(op_id)
    return {"ok": True}


# ---------------------------------------------------------------------------
# 启动
# ---------------------------------------------------------------------------


def _lan_ip() -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except OSError:
        return "127.0.0.1"


if __name__ == "__main__":
    print("=" * 54)
    print("  化学实验故障排查")
    print(f"  电脑访问：http://127.0.0.1:{PORT}")
    print(f"  手机访问：http://{_lan_ip()}:{PORT}  （同一 Wi-Fi）")
    print("  停止服务：按 Ctrl + C")
    print("=" * 54)
    if os.environ.get("LAB_OPEN_BROWSER", "1").lower() not in {"0", "false", "no"}:
        threading.Timer(
            1.2, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}/login")
        ).start()
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")
