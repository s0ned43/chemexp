@echo off
chcp 65001 >nul
title Lab Bench Server
cd /d "%~dp0"
set "LAB_OPEN_BROWSER=0"

set "UV=uv"
where uv >nul 2>nul
if errorlevel 1 goto find_uv
goto run_app

:find_uv
if exist "C:\Users\dell\.cherrystudio\bin\uv.exe" (
  set "UV=C:\Users\dell\.cherrystudio\bin\uv.exe"
  goto run_app
)
if exist "%USERPROFILE%\.local\bin\uv.exe" (
  set "UV=%USERPROFILE%\.local\bin\uv.exe"
  goto run_app
)
echo uv not found. Install uv first, or contact the developer.
pause
exit /b 1

:run_app
"%UV%" run python app.py
if errorlevel 1 (
  echo.
  echo Server stopped with an error. Check the output above.
  pause
)
