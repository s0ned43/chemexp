@echo off
chcp 65001 >nul
title Lab Bench Admin Console
cd /d "%~dp0"

set "UV=uv"
where uv >nul 2>nul
if errorlevel 1 goto find_uv
goto run_app

:find_uv
if exist "C:\Users\dell\.cherrystudio\bin\uv.exe" (
  set "UV=C:\Users\dell\.cherrystudio\bin\uv.exe"
  goto run_app
)
if exist "%USERPROFILE%\.local\bin\uv.exe" (
  set "UV=%USERPROFILE%\.local\bin\uv.exe"
  goto run_app
)
echo uv not found. Install uv first, or contact the developer.
pause
exit /b 1

:run_app
echo.
echo   Lab Bench - Knowledge Base Admin Console
echo   Local URL: http://127.0.0.1:8600/login
echo   Close this window to stop the admin console.
echo.
"%UV%" run python admin_app.py
if errorlevel 1 (
  echo.
  echo Admin console stopped with an error. Check the output above.
  pause
)
